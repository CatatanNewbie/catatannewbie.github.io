<?php
session_start();

// Load data JSON
$data = file_get_contents("product.json");
$produk = json_decode($data, true);

// Ambil ID produk
$id = isset($_GET['id']) ? $_GET['id'] : '';

// Cari produk
$detail = null;
foreach ($produk as $p) {
    if ($p['id'] == $id) {
        $detail = $p;
        break;
    }
}
if (!$detail) {
    header("Location: index.php");
    exit();
}

// Hitung diskon %
$diskon_persen = 0;
if (!empty($detail['harga_asli']) && !empty($detail['harga_diskon']) && $detail['harga_asli'] > 0) {
    $diskon_persen = round((1 - ($detail['harga_diskon'] / $detail['harga_asli'])) * 100);
}

// Count cart untuk navbar
$cart_count = isset($_SESSION["cart"]) ? array_sum(array_column($_SESSION["cart"], "qty")) : 0;

function getColorCode($colorName) {
    $colors = [
        'merah' => '#dc3545',
        'biru' => '#007bff',
        'hijau' => '#28a745',
        'kuning' => '#ffc107',
        'hitam' => '#212529',
        'putih' => '#ffffff',
        'abu-abu' => '#6c757d',
        'coklat' => '#8b4513',
        'ungu' => '#6f42c1',
        'pink' => '#e83e8c',
        'orange' => '#fd7e14'
    ];
    $colorLower = strtolower($colorName);
    return isset($colors[$colorLower]) ? $colors[$colorLower] : '#e83e8c';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($detail['nama']) ?> - Security77 Store</title>
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@800;900&display=swap" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Custom CSS untuk tombol */
        .btn-cart {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 24px;
            font-weight: 600;
            border: none;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        
        .btn-cart:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
            color: white;
        }
        
        .btn-buy-now {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            padding: 12px 24px;
            font-weight: 600;
            border: none;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        
        .btn-buy-now:hover, .btn-buy-now:focus {
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(240, 147, 251, 0.4);
        }
        
        .btn-wishlist {
            background: #f8f9fa;
            border: 2px solid #e9ecef;
            color: #dc3545;
            width: 50px;
            height: 50px;
            border-radius: 8px;
            font-size: 1.2rem;
            transition: all 0.3s ease;
        }
        
        .btn-wishlist:hover, .btn-wishlist.active {
            background: #dc3545;
            color: white;
            border-color: #dc3545;
        }
        
        .btn-out-of-stock {
            background: #6c757d;
            color: white;
            padding: 12px 24px;
            font-weight: 600;
            border: none;
            border-radius: 8px;
            opacity: 0.8;
            cursor: not-allowed;
        }
        
        .payment-methods-dropdown {
            min-width: 280px;
            border-radius: 10px;
            border: 1px solid #e9ecef;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .payment-option {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            border-bottom: 1px solid #f8f9fa;
            transition: all 0.2s ease;
        }
        
        .payment-option:hover {
            background: #f8f9fa;
        }
        
        .payment-option.whatsapp {
            color: #25D366;
        }
        
        .payment-option i {
            font-size: 1.2rem;
            width: 30px;
        }
        
        .payment-option-text {
            flex: 1;
        }
        
        .payment-option-text strong {
            display: block;
            font-size: 0.95rem;
        }
        
        .payment-option-text small {
            color: #6c757d;
            font-size: 0.8rem;
        }
        
        /* Rating stars */
        .stars {
            color: #ffc107;
        }
        
        /* Badge diskon */
        .discount-badge-large {
            position: absolute;
            top: 15px;
            left: 15px;
            background: linear-gradient(135deg, #f5576c 0%, #f093fb 100%);
            color: white;
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 1rem;
            z-index: 1;
        }
        
        /* Ukuran Gambar Produk */
        .main-product-image {
            width: 100%;
            height: 500px;
            object-fit: contain;
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            border: 1px solid #e9ecef;
        }

        .main-image-container {
            position: relative;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        /* Thumbnails */
        .thumbnail-container .thumbnails {
            display: flex;
            gap: 10px;
            overflow-x: auto;
            padding: 10px 0;
        }

        .thumbnail-item {
            width: 80px;
            height: 80px;
            border: 2px solid transparent;
            border-radius: 8px;
            overflow: hidden;
            cursor: pointer;
            flex-shrink: 0;
            transition: all 0.3s ease;
        }

        .thumbnail-item.active {
            border-color: #667eea;
            transform: scale(1.05);
        }

        .thumbnail-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* Out of stock badge */
        .out-of-stock-badge {
            position: absolute;
            top: 15px;
            right: 15px;
            background: rgba(220, 53, 69, 0.95);
            color: white;
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.9rem;
            z-index: 1;
            backdrop-filter: blur(5px);
        }
        
        /* Variant styles */
        .variant-group {
            margin-bottom: 20px;
        }
        
        .variant-title {
            font-weight: 600;
            margin-bottom: 10px;
            color: #333;
        }
        
        .size-options, .color-options, .other-options {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .size-option, .color-option, .other-option {
            position: relative;
            cursor: pointer;
        }
        
        .size-option input, .color-option input, .other-option input {
            display: none;
        }
        
        .size-label {
            display: inline-block;
            padding: 8px 15px;
            border: 2px solid #ddd;
            border-radius: 5px;
            background: white;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .size-option input:checked + .size-label {
            border-color: #667eea;
            background: #667eea;
            color: white;
            font-weight: 600;
        }
        
        .color-label {
            display: inline-block;
            width: 35px;
            height: 35px;
            border-radius: 50%;
            border: 3px solid #ddd;
            transition: all 0.3s;
            position: relative;
        }
        
        .color-option input:checked + .color-label {
            border-color: #667eea;
            transform: scale(1.1);
        }
        
        .color-option input:checked + .color-label::after {
            content: '✓';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
            font-weight: bold;
            text-shadow: 0 0 3px rgba(0,0,0,0.5);
        }
        
        .color-name {
            display: block;
            text-align: center;
            font-size: 12px;
            margin-top: 5px;
        }
        
        .other-label {
            display: inline-block;
            padding: 8px 15px;
            border: 2px solid #ddd;
            border-radius: 5px;
            background: white;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .other-option input:checked + .other-label {
            border-color: #667eea;
            background: #667eea;
            color: white;
            font-weight: 600;
        }
        
        /* Selected variants summary */
        .selected-variants-summary {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
            border-left: 4px solid #667eea;
        }
        
        .selected-variants-title {
            font-weight: 600;
            margin-bottom: 10px;
            color: #333;
        }
        
        .selected-variant-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
            font-size: 14px;
        }
        
        .selected-variant-label {
            color: #666;
        }
        
        .selected-variant-value {
            font-weight: 500;
            color: #333;
        }
        
        /* Toast notification */
        .toast-notification {
            position: fixed;
            bottom: 20px;
            right: 20px;
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            opacity: 0;
            transform: translateY(10px);
            transition: all 0.3s ease;
            z-index: 9999;
            display: flex;
            align-items: center;
        }
        
        .toast-notification.show {
            opacity: 1;
            transform: translateY(0);
        }
        
        .toast-notification.success {
            background: #28a745;
        }
        
        .toast-notification.error {
            background: #dc3545;
        }
        
        .toast-notification.warning {
            background: #ffc107;
            color: #212529;
        }
        
        /* Preview upload */
        .preview-container {
            text-align: center;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 8px;
            border: 1px dashed #dee2e6;
        }
        
        /* Payment info box */
        .payment-info-box {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            border: 1px solid #e9ecef;
        }
        
        .detail-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            padding-bottom: 4px;
            border-bottom: 1px dashed #dee2e6;
        }
        
        .detail-row.total {
            border-bottom: none;
            font-size: 1.1rem;
            margin-top: 10px;
            padding-top: 10px;
            border-top: 2px solid #dee2e6;
        }
        
        /* Crypto address box */
        .crypto-address-box {
            background: #fff;
            border-radius: 8px;
            padding: 15px;
            border: 1px solid #dee2e6;
        }
        
        .bank-info-box {
            background: #fff;
            border-radius: 8px;
            padding: 15px;
            border: 1px solid #dee2e6;
        }
        
        /* Quantity selector */
        .quantity-selector {
            display: flex;
            align-items: center;
            max-width: 150px;
        }
        
        .quantity-btn {
            width: 40px;
            height: 40px;
            border: 1px solid #dee2e6;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .quantity-btn:hover {
            background: #f8f9fa;
        }
        
        .quantity-btn.minus {
            border-radius: 8px 0 0 8px;
        }
        
        .quantity-btn.plus {
            border-radius: 0 8px 8px 0;
        }
        
        .quantity-input {
            width: 60px;
            height: 40px;
            border: 1px solid #dee2e6;
            border-left: none;
            border-right: none;
            text-align: center;
            font-weight: 600;
        }
        
        /* QR Code */
        .qr-code-container {
            text-align: center;
            padding: 15px;
            background: white;
            border-radius: 8px;
            border: 1px solid #dee2e6;
        }
    </style>
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-shield-alt me-2"></i>Security77Store
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarContent">
                <form class="d-flex mx-auto my-2 my-lg-0 w-100" method="GET" action="index.php">
                    <div class="input-group">
                        <input type="text" class="form-control nav-search" placeholder="Cari produk..." name="search">
                        <button class="btn btn-primary" type="submit">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </form>
                
                <div class="d-flex ms-lg-3 mt-3 mt-lg-0">
                    <a href="cart.php" class="btn cart-btn position-relative">
                        <i class="fas fa-shopping-cart"></i>
                        <span class="cart-count"><?= $cart_count ?></span>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- BREADCRUMB -->
    <div class="container mt-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                <?php if (!empty($detail['kategori'])): ?>
                <li class="breadcrumb-item"><a href="index.php?kategori=<?= urlencode($detail['kategori']) ?>"><?= htmlspecialchars($detail['kategori']) ?></a></li>
                <?php endif; ?>
                <li class="breadcrumb-item active" aria-current="page"><?= htmlspecialchars($detail['nama']) ?></li>
            </ol>
        </nav>
    </div>

    <!-- PRODUCT DETAIL -->
    <div class="container py-4 product-detail-container">
        <div class="row">
            <!-- Gambar Produk -->
            <div class="col-lg-6">
                <div class="product-gallery">
                    <div class="main-image-container">
                        <img id="mainProductImage" src="<?= $detail['gambar'] ?>" 
                             alt="<?= htmlspecialchars($detail['nama']) ?>"
                             class="main-product-image"
                             onerror="this.src='https://images.unsplash.com/photo-1559056199-641a0ac8b55e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80'">
                        
                        <?php if ($diskon_persen > 0): ?>
                            <div class="discount-badge-large">
                                <span>-<?= $diskon_persen ?>%</span>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (isset($detail['stok']) && $detail['stok'] <= 0): ?>
                            <div class="out-of-stock-badge">
                                <span>HABIS</span>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Thumbnails -->
                    <?php
                    $thumbs = [];
                    if (!empty($detail['gambar'])) {
                        $thumbs[] = $detail['gambar'];
                    }
                    if (!empty($detail['gambar_lain']) && is_array($detail['gambar_lain'])) {
                        $thumbs = array_merge($thumbs, $detail['gambar_lain']);
                    }
                    
                    if (count($thumbs) > 1):
                    ?>
                    <div class="thumbnail-container mt-4">
                        <h6 class="mb-3">Lihat foto lainnya:</h6>
                        <div class="thumbnails">
                            <?php foreach ($thumbs as $index => $g): ?>
                                <div class="thumbnail-item <?= $index === 0 ? 'active' : '' ?>" 
                                     onclick="changeMainImage('<?= $g ?>', this)">
                                    <img src="<?= $g ?>" 
                                         alt="Thumbnail <?= $index + 1 ?>"
                                         onerror="this.src='https://images.unsplash.com/photo-1559056199-641a0ac8b55e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80'">
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Info Produk -->
            <div class="col-lg-6">
                <div class="product-info-wrapper">
                    <!-- Nama dan Rating -->
                    <h1 class="product-title-detail"><?= htmlspecialchars($detail['nama']) ?></h1>
                    
                    <div class="product-meta mb-4">
                        <?php if (!empty($detail['kategori'])): ?>
                        <span class="product-category-detail">
                            <i class="fas fa-tag me-1"></i>
                            <?= htmlspecialchars($detail['kategori']) ?>
                        </span>
                        <?php endif; ?>
                        <span class="product-sku">
                            <i class="fas fa-hashtag me-1"></i>
                            SKU: <?= $detail['id'] ?>
                        </span>
                    </div>
                    
                    <!-- Rating -->
                    <?php if (!empty($detail['rating']) && !empty($detail['rating_count'])): ?>
                        <div class="rating-section mb-4">
                            <div class="stars">
                                <?php
                                $stars = floor($detail['rating']);
                                $hasHalf = ($detail['rating'] - $stars) >= 0.5;
                                for ($i = 1; $i <= 5; $i++):
                                    if ($i <= $stars):
                                ?>
                                    <i class="fas fa-star"></i>
                                <?php elseif ($i == $stars + 1 && $hasHalf): ?>
                                    <i class="fas fa-star-half-alt"></i>
                                <?php else: ?>
                                    <i class="far fa-star"></i>
                                <?php endif; endfor; ?>
                            </div>
                            <span class="rating-value"><?= number_format($detail['rating'], 1) ?></span>
                            <span class="rating-count">(<?= $detail['rating_count'] ?> ulasan)</span>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Harga -->
                    <div class="price-section mb-4">
                        <div class="current-price">
                            <span class="price-amount">Rp <?= number_format($detail['harga_diskon'], 0, ',', '.') ?></span>
                            <?php if ($diskon_persen > 0): ?>
                                <span class="discount-percentage">-<?= $diskon_persen ?>%</span>
                            <?php endif; ?>
                        </div>
                        
                        <?php if ($detail['harga_asli'] > $detail['harga_diskon']): ?>
                            <div class="original-price">
                                <span class="price-old-text">Rp <?= number_format($detail['harga_asli'], 0, ',', '.') ?></span>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Stok -->
                    <div class="stock-info mb-4">
                        <?php if (isset($detail['stok']) && $detail['stok'] > 0): ?>
                            <div class="stock-available">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                <span class="stock-text">Stok Tersedia: <?= $detail['stok'] ?> unit</span>
                            </div>
                        <?php else: ?>
                            <div class="stock-unavailable">
                                <i class="fas fa-times-circle text-danger me-2"></i>
                                <span class="stock-text">Stok Habis</span>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Summary Varian Terpilih -->
                    <div id="selectedVariantsSummary" class="selected-variants-summary" style="display: none;">
                        <h6 class="selected-variants-title">Varian yang Dipilih:</h6>
                        <div id="selectedVariantsList"></div>
                    </div>
                    
                    <!-- Varian -->
                    <?php if (!empty($detail['varian']) && is_array($detail['varian'])): ?>
                        <div class="variants-section mb-4">
                            <?php if (!empty($detail['varian']['ukuran'])): ?>
                                <div class="variant-group mb-3">
                                    <h6 class="variant-title">Pilih Ukuran:</h6>
                                    <div class="size-options">
                                        <?php foreach ($detail['varian']['ukuran'] as $index => $uk): ?>
                                            <label class="size-option">
                                                <input type="radio" name="size" value="<?= htmlspecialchars($uk) ?>" 
                                                       <?= $index === 0 ? 'checked' : '' ?> 
                                                       onchange="updateSelectedVariants()">
                                                <span class="size-label"><?= htmlspecialchars($uk) ?></span>
                                            </label>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($detail['varian']['warna'])): ?>
                                <div class="variant-group mb-3">
                                    <h6 class="variant-title">Pilih Warna:</h6>
                                    <div class="color-options">
                                        <?php foreach ($detail['varian']['warna'] as $index => $wr): ?>
                                            <label class="color-option">
                                                <input type="radio" name="color" value="<?= htmlspecialchars($wr) ?>" 
                                                       <?= $index === 0 ? 'checked' : '' ?> 
                                                       onchange="updateSelectedVariants()">
                                                <span class="color-label" style="background-color: <?= getColorCode($wr) ?>"></span>
                                                <span class="color-name"><?= htmlspecialchars($wr) ?></span>
                                            </label>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($detail['varian']['lainnya'])): ?>
                                <div class="variant-group mb-3">
                                    <h6 class="variant-title">Pilihan Lain:</h6>
                                    <div class="other-options">
                                        <?php foreach ($detail['varian']['lainnya'] as $index => $other): ?>
                                            <label class="other-option">
                                                <input type="radio" name="other" value="<?= htmlspecialchars($other) ?>" 
                                                       <?= $index === 0 ? 'checked' : '' ?> 
                                                       onchange="updateSelectedVariants()">
                                                <span class="other-label"><?= htmlspecialchars($other) ?></span>
                                            </label>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Kuantitas -->
                    <div class="quantity-section mb-4">
                        <h6 class="quantity-title">Jumlah:</h6>
                        <div class="quantity-selector">
                            <button type="button" class="quantity-btn minus" onclick="decreaseQuantity()">
                                <i class="fas fa-minus"></i>
                            </button>
                            <input type="number" id="productQuantity" class="quantity-input" value="1" min="1" 
                                   max="<?= isset($detail['stok']) ? $detail['stok'] : 10 ?>">
                            <button type="button" class="quantity-btn plus" onclick="increaseQuantity()">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                    
                    <!-- Tombol Aksi -->
                    <div class="action-buttons mb-5">
                        <?php if (isset($detail['stok']) && $detail['stok'] > 0): ?>
                            <form action="cart.php" method="POST" class="d-inline-block me-3">
                                <input type="hidden" name="action" value="add">
                                <input type="hidden" name="id" value="<?= $detail['id'] ?>">
                                <input type="hidden" name="quantity" id="cartQuantity" value="1">
                                <input type="hidden" name="selected_size" id="cartSize">
                                <input type="hidden" name="selected_color" id="cartColor">
                                <input type="hidden" name="selected_other" id="cartOther">
                                <button type="submit" class="btn btn-cart">
                                    <i class="fas fa-shopping-cart me-2"></i>Tambah ke Keranjang
                                </button>
                            </form>
                            
                            <!-- Dropdown Metode Pembayaran untuk Beli Sekarang -->
                            <div class="btn-group d-inline-block me-3">
                                <button type="button" class="btn btn-buy-now dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-bolt me-2"></i>Beli Sekarang
                                </button>
                                <ul class="dropdown-menu payment-methods-dropdown">
                                    <li>
                                        <h6 class="dropdown-header">Pilih Metode Pembayaran:</h6>
                                    </li>
                                    
                                    <!-- Shopee -->
                                    <?php if (!empty($detail['link_marketplace']['shopee'])): ?>
                                        <li>
                                            <a class="dropdown-item payment-option" href="<?= $detail['link_marketplace']['shopee'] ?>" target="_blank">
                                                <i class="fas fa-store me-2"></i>
                                                <div class="payment-option-text">
                                                    <strong>Shopee</strong>
                                                    <small>Beli melalui Shopee</small>
                                                </div>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                    
                                    <!-- Tokopedia -->
                                    <?php if (!empty($detail['link_marketplace']['tokopedia'])): ?>
                                        <li>
                                            <a class="dropdown-item payment-option" href="<?= $detail['link_marketplace']['tokopedia'] ?>" target="_blank">
                                                <i class="fas fa-shopping-bag me-2"></i>
                                                <div class="payment-option-text">
                                                    <strong>Tokopedia</strong>
                                                    <small>Beli melalui Tokopedia</small>
                                                </div>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                    
                                    <!-- Crypto -->
                                    <li>
                                        <a class="dropdown-item payment-option" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#cryptoModal">
                                            <i class="fab fa-bitcoin me-2"></i>
                                            <div class="payment-option-text">
                                                <strong>Crypto</strong>
                                                <small>Bayar dengan Crypto</small>
                                            </div>
                                        </a>
                                    </li>
                                    
                                    <!-- Transfer Bank -->
                                    <li>
                                        <a class="dropdown-item payment-option" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#bankModal">
                                            <i class="fas fa-university me-2"></i>
                                            <div class="payment-option-text">
                                                <strong>Transfer Bank</strong>
                                                <small>Transfer via Bank</small>
                                            </div>
                                        </a>
                                    </li>
                                    
                                    <!-- WhatsApp -->
                                    <li>
                                        <?php
                                        $wa_nomor = "628113317077";
                                        $product_name = urlencode($detail['nama']);
                                        $product_price = number_format($detail['harga_diskon'], 0, ',', '.');
                                        $wa_text = urlencode("Halo, saya ingin membeli produk:\n\n*$product_name*\nHarga: Rp $product_price\n\nBisa dibantu untuk pemesanan?");
                                        $wa_link = "https://wa.me/$wa_nomor?text=$wa_text";
                                        ?>
                                        <a class="dropdown-item payment-option whatsapp" href="<?= $wa_link ?>" target="_blank">
                                            <i class="fab fa-whatsapp me-2"></i>
                                            <div class="payment-option-text">
                                                <strong>WhatsApp</strong>
                                                <small>Chat langsung via WA</small>
                                            </div>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            
                            <!-- Tombol Wishlist -->
                            <button class="btn btn-wishlist" onclick="toggleWishlist()">
                                <i class="far fa-heart"></i>
                            </button>
                        <?php else: ?>
                            <button class="btn btn-out-of-stock" disabled>
                                <i class="fas fa-bell me-2"></i>Notifikasi Saat Stok Tersedia
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>        
        
        <!-- Deskripsi dan Spesifikasi -->
        <div class="row mt-5">
            <div class="col-lg-8">
                <div class="product-tabs">
                    <ul class="nav nav-tabs" id="productTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="description-tab" data-bs-toggle="tab" data-bs-target="#description" type="button">
                                <i class="fas fa-file-alt me-2"></i>Deskripsi
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="specs-tab" data-bs-toggle="tab" data-bs-target="#specs" type="button">
                                <i class="fas fa-list-alt me-2"></i>Spesifikasi
                            </button>
                        </li>
                    </ul>
                    
                    <div class="tab-content p-4" id="productTabContent">
                        <!-- Deskripsi -->
                        <div class="tab-pane fade show active" id="description" role="tabpanel">
                            <h4 class="mb-3">Deskripsi Produk</h4>
                            <?php if (!empty($detail['deskripsi'])): ?>
                                <p class="product-description"><?= nl2br(htmlspecialchars($detail['deskripsi'])) ?></p>
                            <?php else: ?>
                                <p class="text-muted">Deskripsi tidak tersedia untuk produk ini.</p>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Spesifikasi -->
                        <div class="tab-pane fade" id="specs" role="tabpanel">
                            <h4 class="mb-3">Spesifikasi Produk</h4>
                            <div class="specs-table">
                                <?php if (!empty($detail['spesifikasi']) && is_array($detail['spesifikasi'])): ?>
                                    <?php foreach ($detail['spesifikasi'] as $key => $value): ?>
                                        <div class="spec-row">
                                            <div class="spec-key"><?= ucfirst(str_replace('_', ' ', $key)) ?></div>
                                            <div class="spec-value"><?= $value ?></div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <p class="text-muted">Spesifikasi tidak tersedia.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Info Pengiriman -->
            <div class="col-lg-4">
                <div class="delivery-info-card">
                    <h5 class="card-title mb-3">
                        <i class="fas fa-truck me-2"></i>Info Pengiriman
                    </h5>
                    
                    <div class="delivery-option mb-3">
                        <div class="delivery-header">
                            <i class="fas fa-shipping-fast text-primary me-2"></i>
                            <span class="delivery-name">Reguler</span>
                        </div>
                        <div class="delivery-details">
                            <span class="delivery-time">3-5 hari kerja</span>
                            <span class="delivery-price">Rp 15.000</span>
                        </div>
                    </div>
                    
                    <div class="delivery-option mb-3">
                        <div class="delivery-header">
                            <i class="fas fa-rocket text-success me-2"></i>
                            <span class="delivery-name">Express</span>
                        </div>
                        <div class="delivery-details">
                            <span class="delivery-time">1-2 hari kerja</span>
                            <span class="delivery-price">Rp 25.000</span>
                        </div>
                    </div>
                    
                    <div class="delivery-note">
                        <i class="fas fa-info-circle me-2"></i>
                        <small>Gratis ongkir untuk pembelian minimal Rp 300.000</small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL PEMBAYARAN CRYPTO -->
    <div class="modal fade" id="cryptoModal" tabindex="-1" aria-labelledby="cryptoModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="cryptoModalLabel">
                        <i class="fab fa-bitcoin me-2"></i>Pembayaran Crypto
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="cryptoPaymentForm" action="process_payment.php" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="payment_method" value="crypto">
                        <input type="hidden" name="product_id" value="<?= $detail['id'] ?>">
                        <input type="hidden" name="product_name" value="<?= htmlspecialchars($detail['nama']) ?>">
                        <input type="hidden" name="product_price" value="<?= $detail['harga_diskon'] ?>">
                        <input type="hidden" name="quantity" id="cryptoQuantity" value="1">
                        <input type="hidden" name="selected_size" id="cryptoSize">
                        <input type="hidden" name="selected_color" id="cryptoColor">
                        <input type="hidden" name="selected_other" id="cryptoOther">
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="cryptoWallet" class="form-label">Jenis Wallet Crypto <span class="text-danger">*</span></label>
                                    <select class="form-select" id="cryptoWallet" name="crypto_wallet" required onchange="updateCryptoAddress()">
                                        <option value="">Pilih wallet</option>
                                        <option value="bitcoin">Bitcoin (BTC)</option>
                                        <option value="ethereum">Ethereum (ETH)</option>
                                        <option value="binance">Binance Coin (BNB)</option>
                                        <option value="tron">Tron (TRX)</option>
                                        <option value="solana">Solana (SOL)</option>
                                        <option value="usdt">USDT (ERC20/BEP20)</option>
                                        <option value="other">Lainnya</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="cryptoAmount" class="form-label">Jumlah Crypto <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <input type="number" class="form-control" id="cryptoAmount" name="crypto_amount" step="0.000001" required>
                                        <span class="input-group-text" id="cryptoCurrency">BTC</span>
                                    </div>
                                    <small class="text-muted" id="cryptoValueText">≈ Rp <?= number_format($detail['harga_diskon'], 0, ',', '.') ?></small>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="cryptoAddress" class="form-label">Alamat Wallet Anda (Opsional)</label>
                                    <input type="text" class="form-control" id="cryptoAddress" name="crypto_address" 
                                           placeholder="Masukkan alamat wallet Anda (untuk refund jika diperlukan)">
                                    <small class="text-muted">Untuk pengembalian dana jika terjadi kelebihan pembayaran</small>
                                </div>
                                
                                <!-- Upload Bukti Crypto -->
                                <div class="mb-3">
                                    <label for="cryptoPaymentProof" class="form-label">Upload Bukti Pembayaran Crypto <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <input type="file" class="form-control" id="cryptoPaymentProof" name="payment_proof" 
                                               accept=".jpg,.jpeg,.png,.gif,.webp,.pdf" required onchange="previewCryptoImage(this)">
                                        <button class="btn btn-outline-secondary" type="button" onclick="document.getElementById('cryptoPaymentProof').click()">
                                            <i class="fas fa-upload"></i>
                                        </button>
                                    </div>
                                    <div class="form-text">
                                        <i class="fas fa-info-circle me-1"></i>Format: JPG, PNG, GIF, WEBP, PDF (maks. 5MB)
                                    </div>
                                    <div class="form-text text-primary">
                                        <i class="fas fa-paper-plane me-1"></i>Foto akan dikirim otomatis ke Telegram untuk verifikasi cepat
                                    </div>
                                    <div class="preview-container mt-2" id="cryptoPreview" style="display: none;">
                                        <img id="cryptoPreviewImage" src="" alt="Preview" class="img-thumbnail" style="max-height: 150px;">
                                        <button type="button" class="btn btn-sm btn-danger mt-2" onclick="removeCryptoPreview()">
                                            <i class="fas fa-times me-1"></i>Hapus
                                        </button>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="payment-info-box">
                                    <h6 class="mb-3">Informasi Pembayaran</h6>
                                    <div class="payment-details">
                                        <div class="detail-row">
                                            <span>Produk:</span>
                                            <span><?= htmlspecialchars($detail['nama']) ?></span>
                                        </div>
                                        <div class="detail-row">
                                            <span>Harga Satuan:</span>
                                            <span>Rp <?= number_format($detail['harga_diskon'], 0, ',', '.') ?></span>
                                        </div>
                                        <div class="detail-row">
                                            <span>Jumlah:</span>
                                            <span id="cryptoQtyDisplay">1</span>
                                        </div>
                                        
                                        <!-- Summary Varian -->
                                        <div id="cryptoVariantsSummary" class="detail-row">
                                            <span>Varian:</span>
                                            <span id="cryptoSelectedVariants">-</span>
                                        </div>
                                        
                                        <div class="detail-row">
                                            <span>Ongkir:</span>
                                            <span>Rp <span id="cryptoShipping">15.000</span></span>
                                        </div>
                                        <hr>
                                        <div class="detail-row total">
                                            <strong>Total:</strong>
                                            <strong id="cryptoTotalDisplay">Rp <?= number_format($detail['harga_diskon'] + 15000, 0, ',', '.') ?></strong>
                                        </div>
                                    </div>
                                    
                                    <!-- Alamat Crypto Berdasarkan Jenis -->
                                    <div class="crypto-address-box mt-4">
                                        <h6 class="mb-2">Kirim ke Alamat:</h6>
                                        <div class="mb-2">
                                            <code class="crypto-address d-block p-2 bg-white rounded font-monospace text-break" id="targetCryptoAddress">
                                                Pilih jenis crypto untuk melihat alamat
                                            </code>
                                            <small class="text-muted d-block mt-1" id="cryptoNetworkInfo">-</small>
                                        </div>
                                        <button type="button" class="btn btn-sm btn-outline-primary mt-2" onclick="copyCryptoAddress()">
                                            <i class="fas fa-copy me-1"></i>Salin Alamat
                                        </button>
                                        
                                        <!-- QR Code -->
                                        <div class="qr-code-container mt-3">
                                            <h6>QR Code:</h6>
                                            <div id="cryptoQrCode" class="text-center">
                                                <div class="text-muted">Pilih jenis crypto untuk melihat QR Code</div>
                                            </div>
                                        </div>
                                        
                                        <div class="alert alert-warning mt-3">
                                            <i class="fas fa-exclamation-triangle me-1"></i>
                                            <small>Pastikan mengirim ke jaringan yang sesuai dan cek alamat dengan benar!</small>
                                        </div>
                                    </div>
                                    
                                    <div class="alert alert-info mt-3">
                                        <i class="fas fa-info-circle me-2"></i>
                                        <small>Konfirmasi pembayaran maksimal 1x24 jam setelah transfer</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <hr class="my-4">
                        
                        <h5 class="mb-3">Data Pengiriman</h5>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="fullName" class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="fullName" name="full_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="phoneNumber" class="form-label">Nomor HP <span class="text-danger">*</span></label>
                                <input type="tel" class="form-control" id="phoneNumber" name="phone_number" 
                                       pattern="[0-9]{10,13}" placeholder="081234567890" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="address" class="form-label">Alamat Lengkap <span class="text-danger">*</span></label>
                            <textarea class="form-control" id="address" name="address" rows="3" required></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="province" class="form-label">Provinsi <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="province" name="province" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="city" class="form-label">Kota/Kabupaten <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="city" name="city" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="postalCode" class="form-label">Kode Pos <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="postalCode" name="postal_code" required>
                            </div>
                        </div>
                        
                        <div class="form-check mb-4">
                            <input class="form-check-input" type="checkbox" id="termsCrypto" required>
                            <label class="form-check-label" for="termsCrypto">
                                Saya menyetujui <a href="#" target="_blank">syarat dan ketentuan</a> yang berlaku
                            </label>
                        </div>
                        
                        <div class="text-center">
                            <button type="submit" class="btn btn-success btn-lg px-5">
                                <i class="fas fa-lock me-2"></i>Konfirmasi Pembayaran
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL TRANSFER BANK -->
    <div class="modal fade" id="bankModal" tabindex="-1" aria-labelledby="bankModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="bankModalLabel">
                        <i class="fas fa-university me-2"></i>Transfer Bank
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="bankPaymentForm" action="process_payment.php" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="payment_method" value="bank_transfer">
                        <input type="hidden" name="product_id" value="<?= $detail['id'] ?>">
                        <input type="hidden" name="product_name" value="<?= htmlspecialchars($detail['nama']) ?>">
                        <input type="hidden" name="product_price" value="<?= $detail['harga_diskon'] ?>">
                        <input type="hidden" name="quantity" id="bankQuantity" value="1">
                        <input type="hidden" name="selected_size" id="bankSize">
                        <input type="hidden" name="selected_color" id="bankColor">
                        <input type="hidden" name="selected_other" id="bankOther">
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="bankName" class="form-label">Pilih Bank <span class="text-danger">*</span></label>
                                    <select class="form-select" id="bankName" name="bank_name" required onchange="updateBankInfo()">
                                        <option value="">Pilih bank</option>
                                        <option value="bca">BCA</option>
                                        <option value="mandiri">Mandiri</option>
                                        <option value="bni">BNI</option>
                                        <option value="bri">BRI</option>
                                        <option value="cimb">CIMB Niaga</option>
                                        <option value="permata">Permata</option>
                                        <option value="other">Bank Lainnya</option>
                                    </select>
                                </div>
                                
                                <div class="bank-info-box mb-4">
                                    <h6 class="mb-2">Informasi Rekening</h6>
                                    <p><strong>Bank:</strong> <span id="selectedBank">BCA</span></p>
                                    <p><strong>No. Rekening:</strong> <span id="bankAccount">1234567890</span></p>
                                    <p><strong>Atas Nama:</strong> <span id="accountName">SECURITY77 STORE</span></p>
                                    
                                    <button type="button" class="btn btn-sm btn-outline-primary mt-2" onclick="copyBankInfo()">
                                        <i class="fas fa-copy me-1"></i>Salin Info Rekening
                                    </button>
                                </div>
                                
                                <!-- Upload Bukti Transfer Bank -->
                                <div class="mb-3">
                                    <label for="bankPaymentProof" class="form-label">Upload Bukti Transfer <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <input type="file" class="form-control" id="bankPaymentProof" name="payment_proof" 
                                               accept=".jpg,.jpeg,.png,.gif,.webp,.pdf" required onchange="previewBankImage(this)">
                                        <button class="btn btn-outline-secondary" type="button" onclick="document.getElementById('bankPaymentProof').click()">
                                            <i class="fas fa-upload"></i>
                                        </button>
                                    </div>
                                    <div class="form-text">
                                        <i class="fas fa-info-circle me-1"></i>Format: JPG, PNG, GIF, WEBP, PDF (maks. 5MB)
                                    </div>
                                    <div class="form-text text-primary">
                                        <i class="fas fa-paper-plane me-1"></i>Foto bukti transfer akan dikirim ke Telegram
                                    </div>
                                    <div class="preview-container mt-2" id="bankPreview" style="display: none;">
                                        <img id="bankPreviewImage" src="" alt="Preview" class="img-thumbnail" style="max-height: 150px;">
                                        <button type="button" class="btn btn-sm btn-danger mt-2" onclick="removeBankPreview()">
                                            <i class="fas fa-times me-1"></i>Hapus
                                        </button>
                                    </div>
                                </div>
                                
                                <div class="alert alert-warning">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    Harap transfer sesuai nominal total pembayaran
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="payment-info-box">
                                    <h6 class="mb-3">Rincian Pembayaran</h6>
                                    <div class="payment-details">
                                        <div class="detail-row">
                                            <span>Produk:</span>
                                            <span><?= htmlspecialchars($detail['nama']) ?></span>
                                        </div>
                                        <div class="detail-row">
                                            <span>Harga:</span>
                                            <span>Rp <?= number_format($detail['harga_diskon'], 0, ',', '.') ?></span>
                                        </div>
                                        <div class="detail-row">
                                            <span>Jumlah:</span>
                                            <span id="bankQtyDisplay">1</span>
                                        </div>
                                        
                                        <!-- Summary Varian -->
                                        <div id="bankVariantsSummary" class="detail-row">
                                            <span>Varian:</span>
                                            <span id="bankSelectedVariants">-</span>
                                        </div>
                                        
                                        <div class="detail-row">
                                            <span>Ongkir:</span>
                                            <span>Rp 15.000</span>
                                        </div>
                                        <hr>
                                        <div class="detail-row total">
                                            <strong>Total:</strong>
                                            <strong id="bankTotal">Rp <?= number_format($detail['harga_diskon'] + 15000, 0, ',', '.') ?></strong>
                                        </div>
                                    </div>
                                    
                                    <div class="mt-4">
                                        <h6>Kode Unik: <span class="text-primary"><?= rand(100, 999) ?></span></h6>
                                        <small class="text-muted">Tambahkan kode unik untuk mempermudah verifikasi</small>
                                    </div>
                                    
                                    <div class="alert alert-info mt-3">
                                        <i class="fas fa-info-circle me-2"></i>
                                        <small>Konfirmasi pembayaran maksimal 1x24 jam setelah transfer</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <hr class="my-4">
                        
                        <!-- Data Pengiriman -->
                        <h5 class="mb-3">Data Pengiriman</h5>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="bankFullName" class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="bankFullName" name="full_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="bankPhoneNumber" class="form-label">Nomor HP <span class="text-danger">*</span></label>
                                <input type="tel" class="form-control" id="bankPhoneNumber" name="phone_number" 
                                       pattern="[0-9]{10,13}" placeholder="081234567890" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="bankEmail" class="form-label">Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" id="bankEmail" name="email" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="bankAddress" class="form-label">Alamat Lengkap <span class="text-danger">*</span></label>
                            <textarea class="form-control" id="bankAddress" name="address" rows="3" required></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="bankProvince" class="form-label">Provinsi <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="bankProvince" name="province" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="bankCity" class="form-label">Kota/Kabupaten <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="bankCity" name="city" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="bankPostalCode" class="form-label">Kode Pos <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="bankPostalCode" name="postal_code" required>
                            </div>
                        </div>
                        
                        <div class="form-check mb-4">
                            <input class="form-check-input" type="checkbox" id="termsBank" required>
                            <label class="form-check-label" for="termsBank">
                                Saya menyetujui <a href="#" target="_blank">syarat dan ketentuan</a> yang berlaku
                            </label>
                        </div>
                        
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary btn-lg px-5">
                                <i class="fas fa-paper-plane me-2"></i>Kirim Pesanan
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- FOOTER -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 mb-4">
                    <h5>Security77Store</h5>
                    <p>E-commerce terpercaya dengan produk fashion berkualitas tinggi dan harga terbaik.</p>
                    <div class="social-icons mt-3">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-tiktok"></i></a>
                        <a href="#"><i class="fab fa-whatsapp"></i></a>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-6 mb-4">
                    <h5>Menu</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.php" class="footer-link">Home</a></li>
                        <li><a href="#" class="footer-link">Produk</a></li>
                        <li><a href="#" class="footer-link">Kategori</a></li>
                        <li><a href="#" class="footer-link">Promo</a></li>
                    </ul>
                </div>
                
                <div class="col-lg-3 col-md-6 mb-4">
                    <h5>Bantuan</h5>
                    <ul class="list-unstyled">
                        <li><a href="#" class="footer-link">Cara Belanja</a></li>
                        <li><a href="#" class="footer-link">Pengiriman</a></li>
                        <li><a href="#" class="footer-link">Pembayaran</a></li>
                        <li><a href="#" class="footer-link">FAQ</a></li>
                    </ul>
                </div>
                
                <div class="col-lg-3 col-md-6 mb-4">
                    <h5>Kontak</h5>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-phone me-2"></i>0811-3317-077</li>
                        <li><i class="fas fa-envelope me-2"></i>info@security77store.com</li>
                        <li><i class="fas fa-map-marker-alt me-2"></i>Surabaya, Jawa Timur</li>
                    </ul>
                </div>
            </div>
            
            <div class="copyright">
                <p>&copy; <?= date("Y") ?> Security77 Store. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script>
        // Alamat crypto untuk berbagai jenis wallet
        const cryptoAddresses = {
            'bitcoin': {
                address: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh',
                network: 'Bitcoin (BTC Network)',
                qrCode: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=bitcoin:bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh&margin=10'
            },
            'ethereum': {
                address: '0x742d35Cc6634C0532925a3b844Bc9e5a3f5d5b5a',
                network: 'Ethereum (ERC20)',
                qrCode: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=ethereum:0x742d35Cc6634C0532925a3b844Bc9e5a3f5d5b5a&margin=10'
            },
            'binance': {
                address: 'bnb1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh',
                network: 'Binance Chain (BEP2)',
                qrCode: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=bnb1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh&margin=10'
            },
            'tron': {
                address: 'TXYZopYRdj2D9XRtbG411XZZ3kM5VkAeBf',
                network: 'TRON (TRC20)',
                qrCode: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=tron:TXYZopYRdj2D9XRtbG411XZZ3kM5VkAeBf&margin=10'
            },
            'solana': {
                address: 'So11111111111111111111111111111111111111112',
                network: 'Solana (SPL Token)',
                qrCode: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=solana:So11111111111111111111111111111111111111112&margin=10'
            },
            'usdt': {
                address: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
                network: 'USDT (ERC20/BEP20)',
                qrCode: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=0xdAC17F958D2ee523a2206206994597C13D831ec7&margin=10'
            },
            'other': {
                address: 'Pilih jenis crypto lain untuk melihat alamat',
                network: 'Konfirmasi via WhatsApp',
                qrCode: ''
            }
        };

        // Informasi bank
        const bankInfo = {
            'bca': { 
                name: 'BCA', 
                account: '1234567890', 
                holder: 'SECURITY77 STORE' 
            },
            'mandiri': { 
                name: 'Mandiri', 
                account: '0987654321', 
                holder: 'SECURITY77 STORE' 
            },
            'bni': { 
                name: 'BNI', 
                account: '5678901234', 
                holder: 'SECURITY77 STORE' 
            },
            'bri': { 
                name: 'BRI', 
                account: '4321098765', 
                holder: 'SECURITY77 STORE' 
            },
            'cimb': { 
                name: 'CIMB Niaga', 
                account: '6789012345', 
                holder: 'SECURITY77 STORE' 
            },
            'permata': { 
                name: 'Permata', 
                account: '5432109876', 
                holder: 'SECURITY77 STORE' 
            },
            'other': { 
                name: 'Bank Lainnya', 
                account: 'Konfirmasi via WA', 
                holder: 'SECURITY77 STORE' 
            }
        };
        
        // Ubah gambar utama
        function changeMainImage(src, element) {
            document.getElementById('mainProductImage').src = src;
            
            // Hapus class active dari semua thumbnail
            document.querySelectorAll('.thumbnail-item').forEach(item => {
                item.classList.remove('active');
            });
            
            // Tambah class active ke thumbnail yang diklik
            element.classList.add('active');
        }
        
        // Kontrol kuantitas
        let quantity = 1;
        const maxQuantity = <?= isset($detail['stok']) ? $detail['stok'] : 10 ?>;
        
        function increaseQuantity() {
            if (quantity < maxQuantity) {
                quantity++;
                updateQuantity();
            }
        }
        
        function decreaseQuantity() {
            if (quantity > 1) {
                quantity--;
                updateQuantity();
            }
        }
        
        function updateQuantity() {
            const quantityInput = document.getElementById('productQuantity');
            const cartQuantity = document.getElementById('cartQuantity');
            const cryptoQuantity = document.getElementById('cryptoQuantity');
            const bankQuantity = document.getElementById('bankQuantity');
            const bankQtyDisplay = document.getElementById('bankQtyDisplay');
            const cryptoQtyDisplay = document.getElementById('cryptoQtyDisplay');
            
            quantityInput.value = quantity;
            if (cartQuantity) cartQuantity.value = quantity;
            if (cryptoQuantity) cryptoQuantity.value = quantity;
            if (bankQuantity) bankQuantity.value = quantity;
            if (bankQtyDisplay) bankQtyDisplay.textContent = quantity;
            if (cryptoQtyDisplay) cryptoQtyDisplay.textContent = quantity;
            
            // Update total
            updateTotals();
        }
        
        // Update total harga
        function updateTotals() {
            const price = <?= $detail['harga_diskon'] ?>;
            const shipping = 15000;
            const total = (price * quantity) + shipping;
            
            // Update crypto total
            const cryptoTotalDisplay = document.getElementById('cryptoTotalDisplay');
            const cryptoValueText = document.getElementById('cryptoValueText');
            if (cryptoTotalDisplay) {
                cryptoTotalDisplay.textContent = 'Rp ' + formatNumber(total);
            }
            if (cryptoValueText) {
                cryptoValueText.textContent = '≈ Rp ' + formatNumber(price * quantity);
            }
            
            // Update bank total
            const bankTotal = document.getElementById('bankTotal');
            if (bankTotal) {
                bankTotal.textContent = 'Rp ' + formatNumber(total);
            }
        }
        
        // Format number dengan titik
        function formatNumber(num) {
            return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
        }
        
        // Update selected variants
        function updateSelectedVariants() {
            const size = document.querySelector('input[name="size"]:checked')?.value;
            const color = document.querySelector('input[name="color"]:checked')?.value;
            const other = document.querySelector('input[name="other"]:checked')?.value;
            
            // Update hidden fields
            if (document.getElementById('cartSize')) document.getElementById('cartSize').value = size || '';
            if (document.getElementById('cartColor')) document.getElementById('cartColor').value = color || '';
            if (document.getElementById('cartOther')) document.getElementById('cartOther').value = other || '';
            
            if (document.getElementById('cryptoSize')) document.getElementById('cryptoSize').value = size || '';
            if (document.getElementById('cryptoColor')) document.getElementById('cryptoColor').value = color || '';
            if (document.getElementById('cryptoOther')) document.getElementById('cryptoOther').value = other || '';
            
            if (document.getElementById('bankSize')) document.getElementById('bankSize').value = size || '';
            if (document.getElementById('bankColor')) document.getElementById('bankColor').value = color || '';
            if (document.getElementById('bankOther')) document.getElementById('bankOther').value = other || '';
            
            // Update summary display
            const summaryContainer = document.getElementById('selectedVariantsSummary');
            const summaryList = document.getElementById('selectedVariantsList');
            const cryptoSummary = document.getElementById('cryptoSelectedVariants');
            const bankSummary = document.getElementById('bankSelectedVariants');
            
            let html = '';
            let hasVariants = false;
            
            if (size) {
                html += `<span>Ukuran: ${size}</span>`;
                hasVariants = true;
            }
            
            if (color) {
                if (hasVariants) html += ', ';
                html += `<span>Warna: ${color}</span>`;
                hasVariants = true;
            }
            
            if (other) {
                if (hasVariants) html += ', ';
                html += `<span>Pilihan: ${other}</span>`;
                hasVariants = true;
            }
            
            if (!hasVariants) {
                html = '-';
            }
            
            if (cryptoSummary) cryptoSummary.innerHTML = html;
            if (bankSummary) bankSummary.innerHTML = html;
            
            // Show/hide summary
            if (summaryContainer) {
                if (hasVariants) {
                    let detailedHtml = '';
                    if (size) detailedHtml += `<div class="selected-variant-item">
                        <span class="selected-variant-label">Ukuran:</span>
                        <span class="selected-variant-value">${size}</span>
                    </div>`;
                    
                    if (color) detailedHtml += `<div class="selected-variant-item">
                        <span class="selected-variant-label">Warna:</span>
                        <span class="selected-variant-value">${color}</span>
                    </div>`;
                    
                    if (other) detailedHtml += `<div class="selected-variant-item">
                        <span class="selected-variant-label">Pilihan:</span>
                        <span class="selected-variant-value">${other}</span>
                    </div>`;
                    
                    summaryList.innerHTML = detailedHtml;
                    summaryContainer.style.display = 'block';
                } else {
                    summaryContainer.style.display = 'none';
                }
            }
        }
        
        // Update alamat crypto berdasarkan pilihan
        function updateCryptoAddress() {
            const selectedWallet = document.getElementById('cryptoWallet')?.value;
            const cryptoInfo = cryptoAddresses[selectedWallet] || cryptoAddresses['bitcoin'];
            const currencyMap = {
                'bitcoin': 'BTC',
                'ethereum': 'ETH',
                'binance': 'BNB',
                'tron': 'TRX',
                'solana': 'SOL',
                'usdt': 'USDT',
                'other': 'CRYPTO'
            };
            
            // Update alamat
            const targetAddress = document.getElementById('targetCryptoAddress');
            const networkInfo = document.getElementById('cryptoNetworkInfo');
            const cryptoCurrency = document.getElementById('cryptoCurrency');
            
            if (targetAddress) targetAddress.textContent = cryptoInfo.address;
            if (networkInfo) networkInfo.textContent = `Jaringan: ${cryptoInfo.network}`;
            if (cryptoCurrency) cryptoCurrency.textContent = currencyMap[selectedWallet] || 'BTC';
            
            // Update QR Code
            const qrContainer = document.getElementById('cryptoQrCode');
            if (qrContainer) {
                if (cryptoInfo.qrCode && selectedWallet !== 'other') {
                    qrContainer.innerHTML = `<img src="${cryptoInfo.qrCode}" alt="QR Code" class="img-fluid">`;
                } else {
                    qrContainer.innerHTML = '<div class="text-muted">Pilih jenis crypto untuk melihat QR Code</div>';
                }
            }
        }
        
        // Update info bank berdasarkan pilihan
        function updateBankInfo() {
            const selectedBank = document.getElementById('bankName')?.value;
            const info = bankInfo[selectedBank] || bankInfo['bca'];
            
            const selectedBankElement = document.getElementById('selectedBank');
            const bankAccountElement = document.getElementById('bankAccount');
            const accountNameElement = document.getElementById('accountName');
            
            if (selectedBankElement) selectedBankElement.textContent = info.name;
            if (bankAccountElement) bankAccountElement.textContent = info.account;
            if (accountNameElement) accountNameElement.textContent = info.holder;
        }
        
        // Salin alamat crypto
        function copyCryptoAddress() {
            const cryptoAddress = document.getElementById('targetCryptoAddress')?.textContent;
            if (cryptoAddress && cryptoAddress !== 'Pilih jenis crypto untuk melihat alamat') {
                navigator.clipboard.writeText(cryptoAddress).then(() => {
                    showToast('Alamat crypto berhasil disalin!');
                }).catch(err => {
                    showToast('Gagal menyalin alamat', 'error');
                });
            } else {
                showToast('Pilih jenis crypto terlebih dahulu', 'warning');
            }
        }
        
        // Salin info bank
        function copyBankInfo() {
            const selectedBank = document.getElementById('selectedBank')?.textContent;
            const bankAccount = document.getElementById('bankAccount')?.textContent;
            const accountName = document.getElementById('accountName')?.textContent;
            
            const bankInfoText = `Bank: ${selectedBank}\nNo. Rekening: ${bankAccount}\nAtas Nama: ${accountName}`;
            
            navigator.clipboard.writeText(bankInfoText).then(() => {
                showToast('Info rekening berhasil disalin!');
            }).catch(err => {
                showToast('Gagal menyalin info rekening', 'error');
            });
        }
        
        // Toggle wishlist
        function toggleWishlist() {
            const wishlistBtn = document.querySelector('.btn-wishlist');
            const icon = wishlistBtn.querySelector('i');
            
            if (icon.classList.contains('far')) {
                icon.classList.remove('far');
                icon.classList.add('fas');
                wishlistBtn.classList.add('active');
                showToast('Produk ditambahkan ke wishlist!');
            } else {
                icon.classList.remove('fas');
                icon.classList.add('far');
                wishlistBtn.classList.remove('active');
                showToast('Produk dihapus dari wishlist!');
            }
        }
        
        // Preview upload gambar crypto
        function previewCryptoImage(input) {
            if (!validateFileSize(input)) return;
            
            const file = input.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('cryptoPreviewImage').src = e.target.result;
                    document.getElementById('cryptoPreview').style.display = 'block';
                }
                reader.readAsDataURL(file);
            }
        }
        
        // Hapus preview crypto
        function removeCryptoPreview() {
            document.getElementById('cryptoPaymentProof').value = '';
            document.getElementById('cryptoPreview').style.display = 'none';
            document.getElementById('cryptoPreviewImage').src = '';
        }
        
        // Preview upload gambar bank
        function previewBankImage(input) {
            if (!validateFileSize(input)) return;
            
            const file = input.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('bankPreviewImage').src = e.target.result;
                    document.getElementById('bankPreview').style.display = 'block';
                }
                reader.readAsDataURL(file);
            }
        }
        
        // Hapus preview bank
        function removeBankPreview() {
            document.getElementById('bankPaymentProof').value = '';
            document.getElementById('bankPreview').style.display = 'none';
            document.getElementById('bankPreviewImage').src = '';
        }
        
        // Validasi ukuran file upload
        function validateFileSize(input, maxSizeMB = 5) {
            if (input.files && input.files[0]) {
                const file = input.files[0];
                const fileSize = file.size / 1024 / 1024; // MB
                
                // Validasi ukuran file
                if (fileSize > maxSizeMB) {
                    showToast(`File terlalu besar! Maksimal ${maxSizeMB}MB`, 'error');
                    input.value = '';
                    return false;
                }
                
                // Validasi tipe file
                const validTypes = [
                    'image/jpeg', 
                    'image/jpg', 
                    'image/png', 
                    'image/gif', 
                    'image/webp', 
                    'application/pdf'
                ];
                
                if (!validTypes.includes(file.type)) {
                    showToast('Format file tidak didukung! Gunakan JPG, PNG, GIF, WEBP, atau PDF', 'error');
                    input.value = '';
                    return false;
                }
            }
            return true;
        }
        
        // Toast notification
        function showToast(message, type = 'success') {
            const toast = document.createElement('div');
            toast.className = `toast-notification ${type}`;
            
            let icon = 'fas fa-check-circle';
            
            if (type === 'error') {
                icon = 'fas fa-exclamation-circle';
            } else if (type === 'warning') {
                icon = 'fas fa-exclamation-triangle';
            }
            
            toast.innerHTML = `
                <i class="${icon} me-2"></i>
                <span>${message}</span>
            `;
            
            document.body.appendChild(toast);
            
            setTimeout(() => {
                toast.classList.add('show');
            }, 10);
            
            setTimeout(() => {
                toast.classList.remove('show');
                setTimeout(() => {
                    document.body.removeChild(toast);
                }, 300);
            }, 3000);
        }
        
        // Initialize on load
        document.addEventListener('DOMContentLoaded', function() {
            updateSelectedVariants();
            updateTotals();
            updateCryptoAddress();
            updateBankInfo();
            
            // Update kuantitas display
            updateQuantity();
            
            // Update variants ketika modal dibuka
            const cryptoModal = document.getElementById('cryptoModal');
            const bankModal = document.getElementById('bankModal');
            
            if (cryptoModal) {
                cryptoModal.addEventListener('show.bs.modal', function() {
                    setTimeout(() => {
                        updateSelectedVariants();
                        updateCryptoAddress();
                    }, 100);
                });
                
                cryptoModal.addEventListener('hidden.bs.modal', function() {
                    removeCryptoPreview();
                    const form = document.getElementById('cryptoPaymentForm');
                    if (form) form.reset();
                });
            }
            
            if (bankModal) {
                bankModal.addEventListener('show.bs.modal', function() {
                    setTimeout(() => {
                        updateSelectedVariants();
                        updateBankInfo();
                    }, 100);
                });
                
                bankModal.addEventListener('hidden.bs.modal', function() {
                    removeBankPreview();
                    const form = document.getElementById('bankPaymentForm');
                    if (form) form.reset();
                });
            }
            
            // Validasi form saat submit
            const cryptoForm = document.getElementById('cryptoPaymentForm');
            const bankForm = document.getElementById('bankPaymentForm');
            
            if (cryptoForm) {
                cryptoForm.addEventListener('submit', function(e) {
                    const cryptoProof = document.getElementById('cryptoPaymentProof');
                    if (cryptoProof && !cryptoProof.files.length) {
                        e.preventDefault();
                        showToast('Harap upload bukti pembayaran crypto', 'error');
                        return false;
                    }
                    
                    if (!validateFileSize(cryptoProof)) {
                        e.preventDefault();
                        return false;
                    }
                });
            }
            
            if (bankForm) {
                bankForm.addEventListener('submit', function(e) {
                    const bankProof = document.getElementById('bankPaymentProof');
                    if (bankProof && !bankProof.files.length) {
                        e.preventDefault();
                        showToast('Harap upload bukti transfer', 'error');
                        return false;
                    }
                    
                    if (!validateFileSize(bankProof)) {
                        e.preventDefault();
                        return false;
                    }
                });
            }
        });
    </script>
</body>
</html>