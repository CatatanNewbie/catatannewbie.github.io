<?php
session_start();

// API Key RajaOngkir Komerce - HARAP DIGANTI DENGAN API KEY ASLI
define('RAJAONGKIR_API_KEY', 'your_api_key_here');
define('RAJAONGKIR_BASE_URL', 'https://rajaongkir.komerce.id/api/v1');

// Fungsi untuk mendapatkan semua provinsi
function getAllProvinces() {
    try {
        $url = RAJAONGKIR_BASE_URL . '/destination/province';
        $ch = curl_init();
        
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'key: ' . RAJAONGKIR_API_KEY,
            'Content-Type: application/x-www-form-urlencoded'
        ]);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        if ($response) {
            $data = json_decode($response, true);
            return isset($data['data']) ? $data['data'] : [];
        }
        
        return [];
        
    } catch (Exception $e) {
        return [];
    }
}

// Fungsi untuk mendapatkan kota berdasarkan nama (search all provinces)
function findCityByName($cityName) {
    $provinces = getAllProvinces();
    
    if (empty($provinces)) {
        return null;
    }
    
    // Normalize search term
    $searchName = strtolower(trim($cityName));
    $searchName = str_replace(['kota ', 'kabupaten ', 'kab. ', 'city ', 'regency ', ' '], '', $searchName);
    
    foreach ($provinces as $province) {
        $provinceId = $province['id'];
        
        try {
            $url = RAJAONGKIR_BASE_URL . '/destination/city/' . $provinceId;
            $ch = curl_init();
            
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'key: ' . RAJAONGKIR_API_KEY,
                'Content-Type: application/x-www-form-urlencoded'
            ]);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            
            $response = curl_exec($ch);
            curl_close($ch);
            
            if ($response) {
                $data = json_decode($response, true);
                
                if (isset($data['data']) && is_array($data['data'])) {
                    foreach ($data['data'] as $city) {
                        $cityNameLower = strtolower(trim($city['name']));
                        $cityNameClean = str_replace(['kota ', 'kabupaten ', 'kab. ', 'city ', 'regency ', ' '], '', $cityNameLower);
                        
                        // Exact match
                        if ($cityNameClean == $searchName) {
                            return [
                                'city_id' => $city['id'],
                                'province_id' => $provinceId,
                                'city_name' => $city['name'],
                                'province_name' => $province['name']
                            ];
                        }
                        
                        // Partial match
                        if (strpos($cityNameClean, $searchName) !== false || 
                            strpos($searchName, $cityNameClean) !== false) {
                            return [
                                'city_id' => $city['id'],
                                'province_id' => $provinceId,
                                'city_name' => $city['name'],
                                'province_name' => $province['name']
                            ];
                        }
                        
                        // Match for common city names
                        $commonNames = [
                            'jakarta' => ['jakarta', 'dki jakarta', 'jakpus', 'jaktim', 'jakbar', 'jakut', 'jaksel'],
                            'surabaya' => ['surabaya', 'sby'],
                            'bandung' => ['bandung', 'bdg'],
                            'yogyakarta' => ['yogyakarta', 'jogja'],
                            'semarang' => ['semarang'],
                            'medan' => ['medan'],
                            'makassar' => ['makassar'],
                            'denpasar' => ['denpasar']
                        ];
                        
                        foreach ($commonNames as $common => $variations) {
                            if ($searchName == $common) {
                                foreach ($variations as $variation) {
                                    if (strpos($cityNameClean, $variation) !== false) {
                                        return [
                                            'city_id' => $city['id'],
                                            'province_id' => $provinceId,
                                            'city_name' => $city['name'],
                                            'province_name' => $province['name']
                                        ];
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception $e) {
            continue;
        }
    }
    
    return null;
}

// Fungsi untuk mendapatkan kota gudang dari product.json
function getWarehouseCity($productId) {
    $data = file_get_contents("product.json");
    $produk = json_decode($data, true);
    
    foreach ($produk as $p) {
        if ($p['id'] == $productId) {
            return [
                'city_name' => $p['lokasi']['kota'] ?? '',
                'province_name' => $p['lokasi']['provinsi'] ?? '',
                'warehouse_name' => $p['lokasi']['gudang'] ?? ''
            ];
        }
    }
    
    return null;
}

// Ambil data dari POST
$cityName = $_POST['city_name'] ?? '';
$productId = $_POST['product_id'] ?? '';

if (empty($cityName) || empty($productId)) {
    echo json_encode(['success' => false, 'message' => 'Data tidak lengkap']);
    exit();
}

// Dapatkan informasi kota gudang
$warehouseInfo = getWarehouseCity($productId);

if (!$warehouseInfo) {
    echo json_encode(['success' => false, 'message' => 'Produk tidak ditemukan']);
    exit();
}

// Cari ID kota tujuan
$destinationCity = findCityByName($cityName);

if (!$destinationCity) {
    echo json_encode(['success' => false, 'message' => 'Kota tujuan tidak ditemukan: ' . $cityName]);
    exit();
}

// Cari ID kota gudang (origin)
$originCity = findCityByName($warehouseInfo['city_name']);

if (!$originCity) {
    echo json_encode(['success' => false, 'message' => 'Kota gudang tidak ditemukan: ' . $warehouseInfo['city_name']]);
    exit();
}

// Simpan di session
$_SESSION['shipping_city'] = $cityName;
$_SESSION['origin_id'] = $originCity['city_id'];
$_SESSION['destination_id'] = $destinationCity['city_id'];
$_SESSION['origin_city_name'] = $originCity['city_name'];
$_SESSION['destination_city_name'] = $destinationCity['city_name'];

echo json_encode([
    'success' => true,
    'origin_id' => $originCity['city_id'],
    'destination_id' => $destinationCity['city_id'],
    'origin_city' => $originCity['city_name'],
    'destination_city' => $destinationCity['city_name'],
    'warehouse_info' => $warehouseInfo,
    'message' => 'Lokasi ditemukan'
]);
?>