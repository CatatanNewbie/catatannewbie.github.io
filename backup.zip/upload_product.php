<?php
session_start();

// Konfigurasi login
$valid_username = "admin";
$valid_password = "rahasia123";

// Cek login
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        
        if ($username === $valid_username && $password === $valid_password) {
            $_SESSION['loggedin'] = true;
            $_SESSION['username'] = $username;
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        } else {
            $login_error = "Username atau password salah!";
        }
    }
    
    // Tampilkan form login
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login Required - Upload Produk</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                display: flex;
                justify-content: center;
                align-items: center;
                padding: 20px;
            }
            .login-container {
                background: white;
                border-radius: 12px;
                box-shadow: 0 10px 40px rgba(0,0,0,0.1);
                width: 100%;
                max-width: 400px;
                overflow: hidden;
            }
            .login-header {
                background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
                color: white;
                padding: 25px;
                text-align: center;
            }
            .login-form {
                padding: 30px;
            }
            .form-group {
                margin-bottom: 20px;
            }
            label {
                display: block;
                margin-bottom: 8px;
                font-weight: 600;
                color: #374151;
            }
            input[type="text"],
            input[type="password"] {
                width: 100%;
                padding: 12px 15px;
                border: 2px solid #e5e7eb;
                border-radius: 8px;
                font-size: 16px;
                transition: border-color 0.3s;
            }
            input:focus {
                outline: none;
                border-color: #4f46e5;
            }
            .btn {
                width: 100%;
                padding: 12px 24px;
                background: #4f46e5;
                color: white;
                border: none;
                border-radius: 8px;
                font-size: 16px;
                font-weight: 600;
                cursor: pointer;
                transition: background 0.3s;
            }
            .error {
                background: #fee2e2;
                color: #dc2626;
                padding: 10px 15px;
                border-radius: 6px;
                margin-bottom: 20px;
                border: 1px solid #fecaca;
            }
        </style>
    </head>
    <body>
        <div class="login-container">
            <div class="login-header">
                <h1>🔐 Login Required</h1>
                <p>Upload Produk Management System</p>
            </div>
            <div class="login-form">
                <?php if (isset($login_error)): ?>
                    <div class="error"><?php echo $login_error; ?></div>
                <?php endif; ?>
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" required>
                    </div>
                    <input type="hidden" name="login" value="1">
                    <button type="submit" class="btn">Login</button>
                </form>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// ===================================================
// KONFIGURASI FOLDER DAN FILE
$uploadDir = __DIR__ . '/uploads/';
$productsFile = __DIR__ . '/product.json';

// Buat folder upload jika belum ada
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Fungsi untuk upload gambar
function uploadImage($file) {
    global $uploadDir;
    
    if ($file['error'] === UPLOAD_ERR_OK) {
        $allowedTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        $fileName = uniqid() . '_' . basename($file['name']);
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        
        if (in_array($fileExt, $allowedTypes)) {
            $targetFile = $uploadDir . $fileName;
            if (move_uploaded_file($file['tmp_name'], $targetFile)) {
                return 'uploads/' . $fileName;
            }
        }
    }
    return null;
}

// Fungsi untuk format harga
function formatHarga($harga) {
    if (empty($harga)) return 0;
    return intval(str_replace(['.', ','], '', $harga));
}

// Fungsi untuk generate ID baru
function generateNewId($products) {
    $maxId = 0;
    foreach ($products as $product) {
        if (isset($product['id']) && $product['id'] > $maxId) {
            $maxId = $product['id'];
        }
    }
    return $maxId + 1;
}

// Proses form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_product'])) {
    $response = ['status' => 'error', 'message' => ''];
    
    try {
        // Validasi input wajib
        $requiredFields = ['nama', 'harga_asli', 'harga_diskon', 'kategori', 'deskripsi'];
        foreach ($requiredFields as $field) {
            if (empty($_POST[$field])) {
                throw new Exception(ucfirst($field) . ' wajib diisi!');
            }
        }
        
        if (empty($_FILES['gambar']['tmp_name'])) {
            throw new Exception('Gambar utama wajib diupload!');
        }
        
        // Baca data produk yang sudah ada
        $products = [];
        if (file_exists($productsFile)) {
            $jsonData = file_get_contents($productsFile);
            $products = json_decode($jsonData, true) ?? [];
        }
        
        // Upload gambar utama
        $gambarUtama = uploadImage($_FILES['gambar']);
        if (!$gambarUtama) {
            throw new Exception('Gagal upload gambar utama!');
        }
        
        // Upload gambar lain (opsional)
        $gambarLain = [];
        if (!empty($_FILES['gambar_lain']['name'][0])) {
            $count = 0;
            foreach ($_FILES['gambar_lain']['tmp_name'] as $key => $tmpName) {
                if ($count >= 5) break; // Maksimal 5 gambar
                
                if ($_FILES['gambar_lain']['error'][$key] === UPLOAD_ERR_OK) {
                    $file = [
                        'name' => $_FILES['gambar_lain']['name'][$key],
                        'type' => $_FILES['gambar_lain']['type'][$key],
                        'tmp_name' => $tmpName,
                        'error' => $_FILES['gambar_lain']['error'][$key],
                        'size' => $_FILES['gambar_lain']['size'][$key]
                    ];
                    
                    if ($imageName = uploadImage($file)) {
                        $gambarLain[] = $imageName;
                        $count++;
                    }
                }
            }
        }
        
        // Proses variasi - DIPERBAIKI
        $varianData = [];
        
        // CEK APAKAH CHECKBOX "Gunakan variasi ukuran dengan harga & stok berbeda" DICENTANG
        $useDetailedSizes = isset($_POST['use_detailed_sizes']);
        
        if ($useDetailedSizes) {
            // PROSES UKURAN DENGAN HARGA BERBEDA (OPSIONAL)
            if (!empty($_POST['ukuran_nama']) && is_array($_POST['ukuran_nama'])) {
                $ukuranDetails = [];
                foreach ($_POST['ukuran_nama'] as $index => $ukuran) {
                    $ukuran = trim($ukuran);
                    if (!empty($ukuran)) {
                        $harga = isset($_POST['ukuran_harga'][$index]) ? formatHarga($_POST['ukuran_harga'][$index]) : 0;
                        $stok = isset($_POST['ukuran_stok'][$index]) ? intval($_POST['ukuran_stok'][$index]) : 0;
                        
                        if ($harga <= 0) {
                            throw new Exception('Harga untuk ukuran "' . $ukuran . '" harus lebih dari 0!');
                        }
                        
                        $ukuranDetails[] = [
                            'nama' => htmlspecialchars($ukuran),
                            'harga' => $harga,
                            'stok' => $stok
                        ];
                    }
                }
                
                if (!empty($ukuranDetails)) {
                    $varianData['ukuran_detil'] = $ukuranDetails;
                }
            }
        } else {
            // PROSES UKURAN SEDERHANA (tanpa harga berbeda) - OPSIONAL
            if (!empty($_POST['varian_ukuran'])) {
                $ukuranArray = [];
                $ukuranItems = explode(',', $_POST['varian_ukuran']);
                foreach ($ukuranItems as $ukuran) {
                    $ukuran = trim($ukuran);
                    if (!empty($ukuran)) {
                        $ukuranArray[] = htmlspecialchars($ukuran);
                    }
                }
                if (!empty($ukuranArray)) {
                    $varianData['ukuran'] = $ukuranArray;
                }
            }
        }
        
        // Variasi warna (opsional)
        if (!empty($_POST['varian_warna'])) {
            $warnaArray = [];
            $warnaItems = explode(',', $_POST['varian_warna']);
            foreach ($warnaItems as $warna) {
                $warna = trim($warna);
                if (!empty($warna)) {
                    $warnaArray[] = htmlspecialchars($warna);
                }
            }
            if (!empty($warnaArray)) {
                $varianData['warna'] = $warnaArray;
            }
        }
        
        // Variasi lainnya (opsional)
        if (!empty($_POST['varian_lainnya'])) {
            $lainnyaArray = [];
            $lainnyaItems = explode(',', $_POST['varian_lainnya']);
            foreach ($lainnyaItems as $item) {
                $item = trim($item);
                if (!empty($item)) {
                    $lainnyaArray[] = htmlspecialchars($item);
                }
            }
            if (!empty($lainnyaArray)) {
                $varianData['lainnya'] = $lainnyaArray;
            }
        }
        
        // Hitung total stok jika ada variasi detil
        $totalStok = 0;
        if (isset($varianData['ukuran_detil'])) {
            foreach ($varianData['ukuran_detil'] as $detil) {
                $totalStok += $detil['stok'];
            }
        } else {
            $totalStok = intval($_POST['stok'] ?? 0);
        }
        
        // Validasi harga
        $hargaAsli = formatHarga($_POST['harga_asli']);
        $hargaDiskon = formatHarga($_POST['harga_diskon']);
        
        if ($hargaAsli <= 0) {
            throw new Exception('Harga asli harus lebih dari 0!');
        }
        
        if ($hargaDiskon > $hargaAsli) {
            throw new Exception('Harga diskon tidak boleh lebih besar dari harga asli!');
        }
        
        // Data lokasi barang (BARU) - OPSIONAL
        $lokasiData = [];
        if (!empty($_POST['lokasi_gudang'])) {
            $lokasiData = [
                'gudang' => htmlspecialchars($_POST['lokasi_gudang']),
                'kota' => htmlspecialchars($_POST['lokasi_kota'] ?? ''),
                'provinsi' => htmlspecialchars($_POST['lokasi_provinsi'] ?? ''),
                'kode_pos' => htmlspecialchars($_POST['lokasi_kode_pos'] ?? ''),
                'alamat_lengkap' => htmlspecialchars($_POST['lokasi_alamat'] ?? '')
            ];
        }
        
        // Data spesifikasi tambahan - OPSIONAL
        $spesifikasiData = [];
        if (!empty($_POST['material']) || !empty($_POST['dimensi']) || !empty($_POST['garansi'])) {
            $spesifikasiData = [
                'material' => htmlspecialchars($_POST['material'] ?? ''),
                'warna_tersedia' => htmlspecialchars($_POST['warna_tersedia'] ?? ''),
                'berat' => intval($_POST['berat'] ?? 0),
                'dimensi' => htmlspecialchars($_POST['dimensi'] ?? ''),
                'garansi' => htmlspecialchars($_POST['garansi'] ?? '')
            ];
        }
        
        // Buat data produk baru dengan struktur JSON yang jelas
        $newProduct = [
            'id' => generateNewId($products),
            'nama' => htmlspecialchars($_POST['nama']),
            'harga_asli' => $hargaAsli,
            'harga_diskon' => $hargaDiskon,
            'gambar' => $gambarUtama,
            'kategori' => htmlspecialchars($_POST['kategori']),
            'stok' => $totalStok,
            'rating' => floatval($_POST['rating'] ?? 0),
            'rating_count' => intval($_POST['rating_count'] ?? 0),
            'deskripsi' => htmlspecialchars($_POST['deskripsi']),
            
            // Metadata
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        // Tambahkan gambar lain jika ada
        if (!empty($gambarLain)) {
            $newProduct['gambar_lain'] = $gambarLain;
        }
        
        // Tambahkan variasi jika ada (OPSIONAL)
        if (!empty($varianData)) {
            $newProduct['varian'] = $varianData;
        }
        
        // Tambahkan data lokasi jika ada (OPSIONAL)
        if (!empty($lokasiData)) {
            $newProduct['lokasi'] = $lokasiData;
        }
        
        // Tambahkan spesifikasi jika ada (OPSIONAL)
        if (!empty($spesifikasiData)) {
            $newProduct['spesifikasi'] = $spesifikasiData;
        }
        
        // URL marketplace (OPSIONAL)
        $marketplaceUrls = [];
        if (!empty($_POST['shopee_url']) && trim($_POST['shopee_url']) !== '') {
            $marketplaceUrls['shopee'] = htmlspecialchars(trim($_POST['shopee_url']));
        }
        if (!empty($_POST['tokopedia_url']) && trim($_POST['tokopedia_url']) !== '') {
            $marketplaceUrls['tokopedia'] = htmlspecialchars(trim($_POST['tokopedia_url']));
        }
        if (!empty($_POST['crypto_url']) && trim($_POST['crypto_url']) !== '') {
            $marketplaceUrls['crypto'] = htmlspecialchars(trim($_POST['crypto_url']));
        }
        
        if (!empty($marketplaceUrls)) {
            $newProduct['link_marketplace'] = $marketplaceUrls;
        }
        
        // Tambahkan ke array produk
        $products[] = $newProduct;
        
        // Simpan ke file JSON
        $jsonData = json_encode($products, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        if (file_put_contents($productsFile, $jsonData)) {
            $response['status'] = 'success';
            $response['message'] = '✅ Produk berhasil diupload!';
            $response['product'] = $newProduct;
        } else {
            throw new Exception('Gagal menyimpan data ke file JSON!');
        }
        
    } catch (Exception $e) {
        $response['message'] = '❌ Error: ' . $e->getMessage();
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// Fungsi logout
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Produk - JSON Output</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 1000px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
            color: white;
            padding: 25px;
            text-align: center;
            position: relative;
        }
        .form-section {
            padding: 30px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #374151;
        }
        input[type="text"],
        input[type="number"],
        input[type="url"],
        textarea,
        select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        textarea {
            resize: vertical;
            min-height: 100px;
        }
        .btn {
            padding: 12px 24px;
            background: #4f46e5;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s;
            margin-right: 10px;
        }
        .btn:hover {
            background: #4338ca;
        }
        .btn-secondary {
            background: #6b7280;
        }
        .variasi-section,
        .lokasi-section,
        .spesifikasi-section {
            background: #f8fafc;
            padding: 20px;
            border-radius: 8px;
            margin-top: 15px;
            border: 1px solid #e5e7eb;
        }
        .size-detail-row {
            display: grid;
            grid-template-columns: 2fr 2fr 2fr auto;
            gap: 10px;
            margin-bottom: 10px;
            align-items: center;
        }
        .add-size-btn {
            background: #6b7280;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            margin-top: 10px;
        }
        .remove-btn {
            background: #ef4444;
            color: white;
            border: none;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            cursor: pointer;
            font-size: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 25px;
            background: #10b981;
            color: white;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            display: none;
            z-index: 1000;
        }
        .notification.error {
            background: #ef4444;
        }
        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 20px;
            flex-wrap: wrap;
        }
        .optional-label {
            color: #6b7280;
        }
        .optional-label:after {
            content: " (Opsional)";
            font-size: 0.9em;
        }
        .required-label:after {
            content: " *";
            color: #ef4444;
        }
        .grid-2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        .grid-3 {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 15px;
        }
        .section-title {
            margin-bottom: 20px;
            color: #4f46e5;
            padding-bottom: 10px;
            border-bottom: 2px solid #e5e7eb;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📦 Upload Produk ke JSON</h1>
            <p>Form input produk dengan variasi lengkap</p>
            <div style="position: absolute; top: 20px; right: 20px;">
                <a href="?logout=1" style="color: white; text-decoration: none; background: rgba(255,255,255,0.2); padding: 5px 15px; border-radius: 6px;">Logout</a>
            </div>
        </div>
        
        <form id="uploadForm" class="form-section" enctype="multipart/form-data" method="POST">
            <input type="hidden" name="submit_product" value="1">
            
            <!-- INFORMASI DASAR PRODUK -->
            <h2 class="section-title">1. Informasi Dasar Produk</h2>
            
            <!-- 1. Nama Produk -->
            <div class="form-group">
                <label for="nama" class="required-label">Nama Produk</label>
                <input type="text" id="nama" name="nama" required placeholder="Contoh: Sneaker SL57">
            </div>
            
            <!-- 2. Harga Asli -->
            <div class="form-group">
                <label for="harga_asli" class="required-label">Harga Asli</label>
                <input type="text" id="harga_asli" name="harga_asli" required placeholder="250000">
            </div>
            
            <!-- 3. Harga Diskon -->
            <div class="form-group">
                <label for="harga_diskon" class="required-label">Harga Diskon</label>
                <input type="text" id="harga_diskon" name="harga_diskon" required placeholder="180000">
            </div>
            
            <!-- 4. Gambar Utama -->
            <div class="form-group">
                <label for="gambar" class="required-label">Gambar Utama</label>
                <input type="file" id="gambar" name="gambar" accept="image/*" required>
            </div>
            
            <!-- 5. Gambar Lain -->
            <div class="form-group">
                <label for="gambar_lain" class="optional-label">Gambar Lain (Maksimal 5)</label>
                <input type="file" id="gambar_lain" name="gambar_lain[]" accept="image/*" multiple>
            </div>
            
            <!-- 6. Kategori -->
            <div class="form-group">
                <label for="kategori" class="required-label">Kategori</label>
                <select id="kategori" name="kategori" required>
                    <option value="">Pilih Kategori</option>
                    <option value="Sepatu">Sepatu</option>
                    <option value="Fashion">Fashion</option>
                    <option value="Aksesoris">Aksesoris</option>
                    <option value="Elektronik">Elektronik</option>
                    <option value="Kecantikan">Kecantikan</option>
                    <option value="Parfum">Parfum</option>
                    <option value="Pakaian">Pakaian</option>
                    <option value="Olahraga">Olahraga</option>
                    <option value="Rumah Tangga">Rumah Tangga</option>
                </select>
            </div>
            
            <div class="grid-2">
                <!-- 7. Stok Global -->
                <div class="form-group">
                    <label for="stok" class="optional-label">Stok Global</label>
                    <input type="number" id="stok" name="stok" min="0" value="0">
                    <small style="color: #6b7280; font-size: 14px;">* Diisi jika tidak menggunakan variasi ukuran detil</small>
                </div>
                
                <!-- 8. Rating -->
                <div class="form-group">
                    <label for="rating" class="optional-label">Rating</label>
                    <input type="number" id="rating" name="rating" min="0" max="5" step="0.1" value="0">
                </div>
            </div>
            
            <div class="grid-2">
                <!-- 9. Jumlah Rating -->
                <div class="form-group">
                    <label for="rating_count" class="optional-label">Jumlah Rating</label>
                    <input type="number" id="rating_count" name="rating_count" min="0" value="0">
                </div>
                
                <!-- 10. Deskripsi -->
                <div class="form-group">
                    <label for="deskripsi" class="required-label">Deskripsi</label>
                    <textarea id="deskripsi" name="deskripsi" required placeholder="Deskripsi lengkap produk..."></textarea>
                </div>
            </div>
            
            <!-- VARIASI PRODUK -->
            <h2 class="section-title">2. Variasi Produk</h2>
            <div class="variasi-section">
                <!-- 11. Checkbox Detailed Sizes -->
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 8px;">
                        <input type="checkbox" id="use_detailed_sizes" name="use_detailed_sizes" onchange="toggleSizeDetail()">
                        Gunakan variasi ukuran dengan harga & stok berbeda
                    </label>
                    
                    <!-- 12-14. Ukuran Detail (Nama, Harga, Stok) -->
                    <div id="size_detail_section" style="display:none;">
                        <div id="size_detail_rows">
                            <div class="size-detail-row">
                                <input type="text" name="ukuran_nama[]" placeholder="Ukuran (S, M, L)">
                                <input type="text" name="ukuran_harga[]" placeholder="Harga (230000)">
                                <input type="number" name="ukuran_stok[]" placeholder="Stok" min="0" value="0">
                                <button type="button" class="remove-btn" onclick="removeSizeRow(this)" disabled>×</button>
                            </div>
                        </div>
                        <button type="button" class="add-size-btn" onclick="addSizeRow()">+ Tambah Ukuran</button>
                        <small style="color: #6b7280; font-size: 14px; display: block; margin-top: 5px;">* Contoh: Untuk sepatu: 39, 40, 41, 42. Untuk baju: S, M, L, XL</small>
                    </div>
                    
                    <!-- 15. Ukuran Sederhana -->
                    <div id="size_simple_section">
                        <label for="varian_ukuran" class="optional-label">Ukuran (pisahkan dengan koma)</label>
                        <input type="text" id="varian_ukuran" name="varian_ukuran" placeholder="Contoh: S, M, L, XL atau 39, 40, 41, 42">
                    </div>
                </div>
                
                <!-- 16. Warna -->
                <div class="form-group">
                    <label for="varian_warna" class="optional-label">Warna (pisahkan dengan koma)</label>
                    <input type="text" id="varian_warna" name="varian_warna" placeholder="Contoh: Hitam, Putih, Merah, Biru">
                </div>
                
                <!-- 17. Varian Lainnya -->
                <div class="form-group">
                    <label for="varian_lainnya" class="optional-label">Varian Lainnya (pisahkan dengan koma)</label>
                    <input type="text" id="varian_lainnya" name="varian_lainnya" placeholder="Contoh: Original, Premium Box, Limited Edition">
                </div>
            </div>
            
            <!-- LOKASI BARANG -->
            <h2 class="section-title">3. Lokasi Barang</h2>
            <div class="lokasi-section">
                <div class="grid-2">
                    <!-- 18. Gudang -->
                    <div class="form-group">
                        <label for="lokasi_gudang" class="optional-label">Nama Gudang</label>
                        <input type="text" id="lokasi_gudang" name="lokasi_gudang" placeholder="Contoh: Gudang Utama">
                    </div>
                    
                    <!-- 19. Kota -->
                    <div class="form-group">
                        <label for="lokasi_kota" class="optional-label">Kota</label>
                        <input type="text" id="lokasi_kota" name="lokasi_kota" placeholder="Contoh: Jakarta">
                    </div>
                </div>
                
                <div class="grid-2">
                    <!-- 20. Provinsi -->
                    <div class="form-group">
                        <label for="lokasi_provinsi" class="optional-label">Provinsi</label>
                        <input type="text" id="lokasi_provinsi" name="lokasi_provinsi" placeholder="Contoh: DKI Jakarta">
                    </div>
                    
                    <!-- 21. Kode Pos -->
                    <div class="form-group">
                        <label for="lokasi_kode_pos" class="optional-label">Kode Pos</label>
                        <input type="text" id="lokasi_kode_pos" name="lokasi_kode_pos" placeholder="Contoh: 10110">
                    </div>
                </div>
                
                <!-- 22. Alamat Lengkap -->
                <div class="form-group">
                    <label for="lokasi_alamat" class="optional-label">Alamat Lengkap Gudang</label>
                    <textarea id="lokasi_alamat" name="lokasi_alamat" placeholder="Alamat lengkap gudang penyimpanan..."></textarea>
                </div>
            </div>
            
            <!-- SPESIFIKASI TEKNIS -->
            <h2 class="section-title">4. Spesifikasi Teknis</h2>
            <div class="spesifikasi-section">
                <div class="grid-2">
                    <!-- 23. Material -->
                    <div class="form-group">
                        <label for="material" class="optional-label">Material</label>
                        <input type="text" id="material" name="material" placeholder="Contoh: Kulit sintetis, Katun 100%">
                    </div>
                    
                    <!-- 24. Warna Tersedia -->
                    <div class="form-group">
                        <label for="warna_tersedia" class="optional-label">Warna Tersedia</label>
                        <input type="text" id="warna_tersedia" name="warna_tersedia" placeholder="Contoh: Hitam, Putih, Navy Blue">
                    </div>
                </div>
                
                <div class="grid-3">
                    <!-- 25. Berat -->
                    <div class="form-group">
                        <label for="berat" class="optional-label">Berat (gram)</label>
                        <input type="number" id="berat" name="berat" min="0" placeholder="500">
                    </div>
                    
                    <!-- 26. Dimensi -->
                    <div class="form-group">
                        <label for="dimensi" class="optional-label">Dimensi (P x L x T)</label>
                        <input type="text" id="dimensi" name="dimensi" placeholder="Contoh: 30x20x10 cm">
                    </div>
                    
                    <!-- 27. Garansi -->
                    <div class="form-group">
                        <label for="garansi" class="optional-label">Garansi</label>
                        <input type="text" id="garansi" name="garansi" placeholder="Contoh: 1 Tahun">
                    </div>
                </div>
            </div>
            
            <!-- LINK MARKETPLACE -->
            <h2 class="section-title">5. Link Marketplace</h2>
            <div class="form-group">
                <div class="grid-3">
                    <!-- 28. Shopee URL -->
                    <div class="form-group">
                        <label for="shopee_url" class="optional-label">Shopee URL</label>
                        <input type="url" id="shopee_url" name="shopee_url" placeholder="https://shopee.co.id/produk">
                    </div>
                    
                    <!-- 29. Tokopedia URL -->
                    <div class="form-group">
                        <label for="tokopedia_url" class="optional-label">Tokopedia URL</label>
                        <input type="url" id="tokopedia_url" name="tokopedia_url" placeholder="https://tokopedia.com/produk">
                    </div>
                    
                    <!-- 30. Crypto URL -->
                    <div class="form-group">
                        <label for="crypto_url" class="optional-label">Crypto URL</label>
                        <input type="url" id="crypto_url" name="crypto_url" placeholder="https://payment-crypto-link.com">
                    </div>
                </div>
            </div>
            
            <div class="action-buttons">
                <button type="submit" class="btn">📤 Upload Produk ke JSON</button>
                <button type="button" class="btn btn-secondary" onclick="previewJSON()">👁️ Preview JSON</button>
                <button type="button" class="btn btn-secondary" onclick="viewProducts()">📋 Lihat Produk</button>
                <button type="button" class="btn btn-secondary" onclick="clearForm()">🗑️ Reset Form</button>
            </div>
        </form>
    </div>
    
    <div id="notification" class="notification"></div>
    
    <script>
        function toggleSizeDetail() {
            const useDetailed = document.getElementById('use_detailed_sizes').checked;
            document.getElementById('size_detail_section').style.display = useDetailed ? 'block' : 'none';
            document.getElementById('size_simple_section').style.display = useDetailed ? 'none' : 'block';
        }
        
        function addSizeRow() {
            const container = document.getElementById('size_detail_rows');
            const rows = container.querySelectorAll('.size-detail-row');
            
            // Enable remove button on first row if there are multiple rows
            if (rows.length === 1) {
                const firstRemoveBtn = rows[0].querySelector('.remove-btn');
                firstRemoveBtn.disabled = false;
                firstRemoveBtn.style.backgroundColor = '#ef4444';
            }
            
            const row = document.createElement('div');
            row.className = 'size-detail-row';
            row.innerHTML = `
                <input type="text" name="ukuran_nama[]" placeholder="Ukuran" required>
                <input type="text" name="ukuran_harga[]" placeholder="Harga" required>
                <input type="number" name="ukuran_stok[]" placeholder="Stok" min="0" required>
                <button type="button" class="remove-btn" onclick="removeSizeRow(this)">×</button>
            `;
            container.appendChild(row);
        }
        
        function removeSizeRow(button) {
            const container = document.getElementById('size_detail_rows');
            const rows = container.querySelectorAll('.size-detail-row');
            
            if (rows.length > 1) {
                button.parentElement.remove();
                
                // If only one row left, disable its remove button
                if (rows.length === 2) { // 2 because we haven't removed yet
                    const firstRemoveBtn = container.querySelector('.size-detail-row .remove-btn');
                    firstRemoveBtn.disabled = true;
                    firstRemoveBtn.style.backgroundColor = '#9ca3af';
                }
            }
        }
        
        function showNotification(message, isError = false) {
            const notification = document.getElementById('notification');
            notification.textContent = message;
            notification.className = 'notification' + (isError ? ' error' : '');
            notification.style.display = 'block';
            
            setTimeout(() => {
                notification.style.display = 'none';
            }, 5000);
        }
        
        function previewJSON() {
            const form = document.getElementById('uploadForm');
            const formData = new FormData(form);
            const data = {};
            
            // Collect all form data
            for (let [key, value] of formData.entries()) {
                if (key === 'submit_product') continue;
                
                if (key.includes('[]')) {
                    const baseKey = key.replace('[]', '');
                    if (!data[baseKey]) data[baseKey] = [];
                    if (value) data[baseKey].push(value);
                } else {
                    if (value) data[key] = value;
                }
            }
            
            // Process ukuran_detil if checkbox is checked
            const useDetailedSizes = document.getElementById('use_detailed_sizes').checked;
            const ukuranDetil = [];
            
            if (useDetailedSizes && data.ukuran_nama) {
                data.ukuran_nama.forEach((nama, index) => {
                    if (nama.trim()) {
                        ukuranDetil.push({
                            nama: nama.trim(),
                            harga: parseInt(data.ukuran_harga[index]?.replace(/\D/g, '') || 0),
                            stok: parseInt(data.ukuran_stok[index] || 0)
                        });
                    }
                });
            }
            
            // Build preview object
            const previewData = {
                id: "auto_generated",
                nama: data.nama || "",
                harga_asli: parseInt(data.harga_asli?.replace(/\D/g, '') || 0),
                harga_diskon: parseInt(data.harga_diskon?.replace(/\D/g, '') || 0),
                gambar: "uploads/image.jpg",
                kategori: data.kategori || "",
                stok: parseInt(data.stok || 0),
                rating: parseFloat(data.rating || 0),
                rating_count: parseInt(data.rating_count || 0),
                deskripsi: data.deskripsi || "",
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
            };
            
            // Add optional fields if they exist
            const optionalFields = {};
            
            // Variasi
            if (useDetailedSizes && ukuranDetil.length > 0) {
                optionalFields.varian = { ukuran_detil: ukuranDetil };
            } else if (data.varian_ukuran) {
                const ukuranArray = data.varian_ukuran.split(',').map(s => s.trim()).filter(s => s);
                if (ukuranArray.length > 0) {
                    optionalFields.varian = { ukuran: ukuranArray };
                }
            }
            
            if (data.varian_warna) {
                const warnaArray = data.varian_warna.split(',').map(s => s.trim()).filter(s => s);
                if (warnaArray.length > 0) {
                    if (!optionalFields.varian) optionalFields.varian = {};
                    optionalFields.varian.warna = warnaArray;
                }
            }
            
            if (data.varian_lainnya) {
                const lainnyaArray = data.varian_lainnya.split(',').map(s => s.trim()).filter(s => s);
                if (lainnyaArray.length > 0) {
                    if (!optionalFields.varian) optionalFields.varian = {};
                    optionalFields.varian.lainnya = lainnyaArray;
                }
            }
            
            // Lokasi
            if (data.lokasi_gudang) {
                optionalFields.lokasi = {
                    gudang: data.lokasi_gudang,
                    kota: data.lokasi_kota || "",
                    provinsi: data.lokasi_provinsi || "",
                    kode_pos: data.lokasi_kode_pos || "",
                    alamat_lengkap: data.lokasi_alamat || ""
                };
            }
            
            // Spesifikasi
            if (data.material || data.dimensi || data.garansi) {
                optionalFields.spesifikasi = {
                    material: data.material || "",
                    warna_tersedia: data.warna_tersedia || "",
                    berat: parseInt(data.berat || 0),
                    dimensi: data.dimensi || "",
                    garansi: data.garansi || ""
                };
            }
            
            // Marketplace links
            const marketplaceUrls = {};
            if (data.shopee_url && data.shopee_url.trim() !== '') {
                marketplaceUrls.shopee = data.shopee_url;
            }
            if (data.tokopedia_url && data.tokopedia_url.trim() !== '') {
                marketplaceUrls.tokopedia = data.tokopedia_url;
            }
            if (data.crypto_url && data.crypto_url.trim() !== '') {
                marketplaceUrls.crypto = data.crypto_url;
            }
            
            if (Object.keys(marketplaceUrls).length > 0) {
                optionalFields.link_marketplace = marketplaceUrls;
            }
            
            // Merge optional fields
            Object.assign(previewData, optionalFields);
            
            // Show preview
            const previewWindow = window.open('', '_blank');
            previewWindow.document.write(`
                <html>
                <head>
                    <title>Preview JSON Produk</title>
                    <style>
                        body { font-family: monospace; padding: 20px; background: #f5f5f5; }
                        pre { background: white; padding: 20px; border-radius: 5px; border: 1px solid #ddd; }
                        .copy-btn { 
                            margin-bottom: 10px; 
                            padding: 10px 20px; 
                            background: #4f46e5; 
                            color: white; 
                            border: none; 
                            border-radius: 5px; 
                            cursor: pointer; 
                        }
                    </style>
                </head>
                <body>
                    <button class="copy-btn" onclick="copyJSON()">📋 Copy JSON</button>
                    <pre id="jsonOutput">${JSON.stringify(previewData, null, 2)}</pre>
                    <script>
                        function copyJSON() {
                            const text = document.getElementById('jsonOutput').textContent;
                            navigator.clipboard.writeText(text).then(() => {
                                alert('JSON copied to clipboard!');
                            });
                        }
                    <\/script>
                </body>
                </html>
            `);
        }
        
        function viewProducts() {
            window.open('product.json', '_blank');
        }
        
        function clearForm() {
            if (confirm('Yakin ingin mengosongkan form?')) {
                document.getElementById('uploadForm').reset();
                const sizeRows = document.getElementById('size_detail_rows');
                sizeRows.innerHTML = `
                    <div class="size-detail-row">
                        <input type="text" name="ukuran_nama[]" placeholder="Ukuran">
                        <input type="text" name="ukuran_harga[]" placeholder="Harga">
                        <input type="number" name="ukuran_stok[]" placeholder="Stok" min="0">
                        <button type="button" class="remove-btn" onclick="removeSizeRow(this)" disabled>×</button>
                    </div>
                `;
                document.getElementById('use_detailed_sizes').checked = false;
                toggleSizeDetail();
            }
        }
        
        // Handle form submission dengan AJAX
        document.getElementById('uploadForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '⏳ Mengupload...';
            submitBtn.disabled = true;
            
            fetch('<?php echo $_SERVER["PHP_SELF"]; ?>', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    showNotification(data.message);
                    clearForm();
                    // Log the JSON structure to console
                    console.log('Produk berhasil diupload:', data.product);
                } else {
                    showNotification(data.message, true);
                }
            })
            .catch(error => {
                showNotification('Terjadi kesalahan: ' + error.message, true);
            })
            .finally(() => {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            });
        });
        
        // Format harga input
        ['harga_asli', 'harga_diskon'].forEach(id => {
            document.getElementById(id).addEventListener('input', function(e) {
                let value = this.value.replace(/\D/g, '');
                if (value) {
                    this.value = parseInt(value).toLocaleString('id-ID');
                }
            });
        });
        
        // Format harga untuk ukuran detail
        document.addEventListener('input', function(e) {
            if (e.target.name === 'ukuran_harga[]') {
                let value = e.target.value.replace(/\D/g, '');
                if (value) {
                    e.target.value = parseInt(value).toLocaleString('id-ID');
                }
            }
        });
    </script>
</body>
</html>