<?php
session_start();

// API Key RajaOngkir Komerce - HARAP DIGANTI DENGAN API KEY ASLI
define('RAJAONGKIR_API_KEY', 'bpWWWQd19324ba570f7363afCNAZIDXi');
define('RAJAONGKIR_BASE_URL', 'https://rajaongkir.komerce.id/api/v1');

// Fungsi untuk mendapatkan ID province
// FUNGSI UNTUK MENDAPATKAN ID PROVINCE DARI RAJAONGKIR (VERSI DIPERBAIKI)
function getProvinceId($provinceName) {
    try {
        $url = RAJAONGKIR_BASE_URL . '/destination/province';
        $ch = curl_init();
        
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'key: ' . RAJAONGKIR_API_KEY,
            'Content-Type: application/x-www-form-urlencoded'
        ]);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($http_code === 200 && $response) {
            $data = json_decode($response, true);
            
            if (isset($data['data']) && is_array($data['data'])) {
                // Normalize province name
                $searchName = strtolower(trim($provinceName));
                $searchName = str_replace(['dki ', 'di ', 'daerah ', 'khusus ', 'istimewa '], '', $searchName);
                
                foreach ($data['data'] as $province) {
                    $provinceNameLower = strtolower(trim($province['name']));
                    $provinceNameLower = str_replace(['dki ', 'di ', 'daerah ', 'khusus ', 'istimewa '], '', $provinceNameLower);
                    
                    // Exact match atau partial match
                    if ($provinceNameLower == $searchName || 
                        strpos($provinceNameLower, $searchName) !== false ||
                        strpos($searchName, $provinceNameLower) !== false) {
                        return $province['id'];
                    }
                }
                
                // Fallback: cari dengan kata kunci umum
                $keywords = [
                    'jakarta' => ['jakarta', 'dki jakarta', 'jakarta pusat'],
                    'jawa barat' => ['jawa barat', 'west java', 'jabar'],
                    'jawa timur' => ['jawa timur', 'east java', 'jatim'],
                    'jawa tengah' => ['jawa tengah', 'central java', 'jateng'],
                    'bali' => ['bali'],
                    'surabaya' => ['surabaya', 'sby'],
                    'bandung' => ['bandung', 'bdg'],
                    'yogyakarta' => ['yogyakarta', 'jogja', 'diy']
                ];
                
                if (isset($keywords[$searchName])) {
                    foreach ($data['data'] as $province) {
                        $provinceNameLower = strtolower(trim($province['name']));
                        foreach ($keywords[$searchName] as $keyword) {
                            if (strpos($provinceNameLower, $keyword) !== false) {
                                return $province['id'];
                            }
                        }
                    }
                }
            }
        }
        
        return null;
        
    } catch (Exception $e) {
        error_log("Error getting province ID: " . $e->getMessage());
        return null;
    }
}

// FUNGSI UNTUK MENDAPATKAN ID KOTA DARI RAJAONGKIR (VERSI DIPERBAIKI)
function getCityId($provinceId, $cityName) {
    try {
        $url = RAJAONGKIR_BASE_URL . '/destination/city/' . $provinceId;
        $ch = curl_init();
        
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'key: ' . RAJAONGKIR_API_KEY,
            'Content-Type: application/x-www-form-urlencoded'
        ]);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($http_code === 200 && $response) {
            $data = json_decode($response, true);
            
            if (isset($data['data']) && is_array($data['data'])) {
                // Normalize city name
                $searchName = strtolower(trim($cityName));
                $searchName = str_replace(['kota ', 'kabupaten ', 'kab. ', 'kab ', 'city ', 'regency '], '', $searchName);
                
                // First pass: exact match
                foreach ($data['data'] as $city) {
                    $cityNameLower = strtolower(trim($city['name']));
                    $cityNameLowerClean = str_replace(['kota ', 'kabupaten ', 'kab. ', 'kab ', 'city ', 'regency '], '', $cityNameLower);
                    
                    if ($cityNameLowerClean == $searchName || 
                        $cityNameLower == $searchName ||
                        strpos($cityNameLower, $searchName) !== false ||
                        strpos($searchName, $cityNameLowerClean) !== false) {
                        return $city['id'];
                    }
                }
                
                // Second pass: keyword matching
                $keywords = [
                    'jakarta' => ['jakarta', 'dki jakarta', 'jakarta pusat', 'jakarta utara', 'jakarta selatan', 'jakarta timur', 'jakarta barat'],
                    'surabaya' => ['surabaya', 'sby'],
                    'bandung' => ['bandung', 'bdg'],
                    'yogyakarta' => ['yogyakarta', 'jogja'],
                    'semarang' => ['semarang'],
                    'medan' => ['medan'],
                    'makassar' => ['makassar', 'ujung pandang'],
                    'palembang' => ['palembang'],
                    'denpasar' => ['denpasar'],
                    'bogor' => ['bogor'],
                    'depok' => ['depok'],
                    'tangerang' => ['tangerang'],
                    'bekasi' => ['bekasi']
                ];
                
                if (isset($keywords[$searchName])) {
                    foreach ($data['data'] as $city) {
                        $cityNameLower = strtolower(trim($city['name']));
                        foreach ($keywords[$searchName] as $keyword) {
                            if (strpos($cityNameLower, $keyword) !== false) {
                                return $city['id'];
                            }
                        }
                    }
                }
                
                // Third pass: try to match without special characters
                $searchNameClean = preg_replace('/[^a-z]/', '', $searchName);
                foreach ($data['data'] as $city) {
                    $cityNameLower = strtolower(trim($city['name']));
                    $cityNameClean = preg_replace('/[^a-z]/', '', $cityNameLower);
                    
                    if ($cityNameClean == $searchNameClean) {
                        return $city['id'];
                    }
                }
            }
        }
        
        return null;
        
    } catch (Exception $e) {
        error_log("Error getting city ID: " . $e->getMessage());
        return null;
    }
}
?>