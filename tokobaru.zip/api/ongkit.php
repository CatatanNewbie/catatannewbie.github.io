<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
// API KEY RAJAONGKIR
$API_KEY = 'bpWWWQd19324ba570f7363afCNAZIDXi'; // Ganti dengan API Key Anda

// Ambil parameter dari URL
$origin = $_GET['origin'] ?? '';
$destination = $_GET['destination'] ?? '';
$weight = $_GET['weight'] ?? 1000;
$courier = $_GET['courier'] ?? 'jne';

// Validasi parameter wajib
if (empty($origin) || empty($destination)) {
    echo json_encode(['error' => 'Parameter origin dan destination diperlukan']);
    exit;
}

// Jika parameter adalah angka, langsung hitung ongkir
// Jika parameter adalah nama kota, cari ID kota dulu
if (is_numeric($origin)) {
    $origin_id = $origin;
} else {
    // Cari ID kota asal
    $ch = curl_init('https://rajaongkir.komerce.id/api/v1/destination/domestic-destination?search=' . urlencode($origin));
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => ['key: ' . $API_KEY]
    ]);
    $response = json_decode(curl_exec($ch), true);
    curl_close($ch);
    $origin_id = $response['data'][0]['id'] ?? null;
}

if (is_numeric($destination)) {
    $destination_id = $destination;
} else {
    // Cari ID kota tujuan
    $ch = curl_init('https://rajaongkir.komerce.id/api/v1/destination/domestic-destination?search=' . urlencode($destination));
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => ['key: ' . $API_KEY]
    ]);
    $response = json_decode(curl_exec($ch), true);
    curl_close($ch);
    $destination_id = $response['data'][0]['id'] ?? null;
}

// Jika kota tidak ditemukan
if (!$origin_id || !$destination_id) {
    echo json_encode(['error' => 'Kota tidak ditemukan']);
    exit;
}

// HITUNG ONGKIR
$ch = curl_init('https://rajaongkir.komerce.id/api/v1/calculate/domestic-cost');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => "origin=$origin_id&destination=$destination_id&weight=$weight&courier=$courier",
    CURLOPT_HTTPHEADER => [
        'key: ' . $API_KEY,
        'Content-Type: application/x-www-form-urlencoded'
    ]
]);

$response = curl_exec($ch);
curl_close($ch);

// Output response langsung dari API
header('Content-Type: application/json');
echo $response;