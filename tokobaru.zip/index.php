<?php
session_start();

// Load Produk dari JSON
$data = file_get_contents("product.json");
$produk = json_decode($data, true);

// Search
$keyword = isset($_GET["search"]) ? strtolower($_GET["search"]) : "";
$filterKategori = isset($_GET["kategori"]) ? $_GET["kategori"] : "";

// Filter by search
if ($keyword !== "") {
    $hasil = [];
    foreach ($produk as $p) {
        if (
            strpos(strtolower($p["nama"]), $keyword) !== false ||
            strpos(strtolower($p["kategori"]), $keyword) !== false ||
            strpos(strtolower($p["deskripsi"]), $keyword) !== false
        ) {
            $hasil[] = $p;
        }
    }
    $produk = $hasil;
}

// Filter kategori
if ($filterKategori !== "") {
    $filtered = [];
    foreach ($produk as $p) {
        if (strtolower($p["kategori"]) === strtolower($filterKategori)) {
            $filtered[] = $p;
        }
    }
    $produk = $filtered;
}

// Count cart
$cart_count = isset($_SESSION["cart"]) ? array_sum(array_column($_SESSION["cart"], "qty")) : 0;

// Ambil kategori unik untuk filter
$kategori_unik = [];
foreach (json_decode($data, true) as $p) {
    if (!in_array($p["kategori"], $kategori_unik)) {
        $kategori_unik[] = $p["kategori"];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Virallinstore.id - Fashion Store Terpercaya</title>
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&family=Montserrat:wght@800;900&display=swap" rel="stylesheet">
    
    <!-- Custom CSS -->
    <style>
        :root {
            --primary-color: #6366f1;
            --secondary-color: #8b5cf6;
            --accent-color: #f59e0b;
            --dark-color: #1f2937;
            --light-color: #f8fafc;
            --gray-color: #94a3b8;
            --success-color: #10b981;
            --danger-color: #ef4444;
            --shadow-sm: 0 2px 8px rgba(0,0,0,0.08);
            --shadow-md: 0 4px 16px rgba(0,0,0,0.12);
            --shadow-lg: 0 8px 32px rgba(0,0,0,0.15);
            --radius-sm: 12px;
            --radius-md: 16px;
            --radius-lg: 24px;
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9fafb;
            color: var(--dark-color);
            line-height: 1.6;
        }

        /* NAVBAR */
        .navbar {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            box-shadow: var(--shadow-sm);
            padding: 1rem 0;
            position: sticky;
            top: 0;
            z-index: 1000;
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(99, 102, 241, 0.1);
        }

        .navbar-brand {
            font-family: 'Montserrat', sans-serif;
            font-weight: 900;
            font-size: 1.8rem;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .navbar-brand i {
            font-size: 1.5rem;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .nav-search {
            border-radius: 50px;
            border: 2px solid #e2e8f0;
            padding: 0.75rem 1.5rem;
            font-size: 0.95rem;
            transition: var(--transition);
            min-width: 250px;
        }

        .nav-search:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
            outline: none;
        }

        .search-btn {
            border-radius: 50px;
            padding: 0.75rem 1.5rem;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            transition: var(--transition);
        }

        .search-btn:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }

        .cart-btn {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            border-radius: 50px;
            padding: 0.75rem 1.5rem;
            color: white;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: var(--transition);
            text-decoration: none;
        }

        .cart-btn:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
            color: white;
        }

        .cart-count {
            position: absolute;
            top: -8px;
            right: -8px;
            background: var(--danger-color);
            color: white;
            font-size: 0.75rem;
            width: 22px;
            height: 22px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }

        /* BANNER */
        .carousel-inner {
            border-radius: var(--radius-lg);
            overflow: hidden;
            box-shadow: var(--shadow-lg);
        }

        .banner-img {
            height: 400px;
            object-fit: cover;
            width: 100%;
        }

        .carousel-control-prev,
        .carousel-control-next {
            width: 60px;
            height: 60px;
            background: rgba(255, 255, 255, 0.9);
            border-radius: 50%;
            top: 50%;
            transform: translateY(-50%);
            margin: 0 20px;
            box-shadow: var(--shadow-md);
            opacity: 0.8;
            transition: var(--transition);
        }

        .carousel-control-prev:hover,
        .carousel-control-next:hover {
            opacity: 1;
            transform: translateY(-50%) scale(1.1);
        }

        .carousel-indicators [data-bs-target] {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin: 0 5px;
            border: 2px solid white;
            background: transparent;
        }

        .carousel-indicators .active {
            background: white;
        }

        /* CATEGORY FILTER */
        .category-filter {
            background: white;
            padding: 1.5rem;
            border-radius: var(--radius-md);
            box-shadow: var(--shadow-sm);
            margin-bottom: 2rem;
        }

        .category-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            justify-content: center;
        }

        .category-btn {
            border: 2px solid #e2e8f0;
            border-radius: 50px;
            padding: 0.5rem 1.25rem;
            font-size: 0.9rem;
            color: var(--dark-color);
            transition: var(--transition);
            white-space: nowrap;
        }

        .category-btn:hover,
        .category-btn.active {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border-color: transparent;
            transform: translateY(-2px);
            box-shadow: var(--shadow-sm);
        }

        /* PRODUCTS SECTION */
        .section-header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .section-header h2 {
            font-family: 'Montserrat', sans-serif;
            font-weight: 900;
            font-size: 2.5rem;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 0.5rem;
        }

        /* PRODUCT CARDS - HORIZONTAL LAYOUT */
        .product-table-container {
            background: white;
            border-radius: var(--radius-md);
            box-shadow: var(--shadow-sm);
            padding: 1.5rem;
            margin-bottom: 2rem;
        }

        .product-table {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .product-row {
            display: grid;
            grid-template-columns: 120px 2fr 1fr 1fr 150px;
            gap: 1rem;
            align-items: center;
            padding: 1rem;
            background: #f8fafc;
            border-radius: var(--radius-sm);
            transition: var(--transition);
            border: 1px solid transparent;
        }

        .product-row:hover {
            background: white;
            border-color: var(--primary-color);
            box-shadow: var(--shadow-sm);
            transform: translateY(-2px);
        }

        .product-image-cell {
            position: relative;
            height: 100px;
            border-radius: var(--radius-sm);
            overflow: hidden;
        }

        .product-image-cell img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .product-row:hover .product-image-cell img {
            transform: scale(1.05);
        }

        .product-diskon-badge {
            position: absolute;
            top: 8px;
            left: 8px;
            background: linear-gradient(135deg, var(--danger-color), #f87171);
            color: white;
            padding: 0.3rem 0.6rem;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 700;
            z-index: 2;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }

        .product-info-cell {
            padding-right: 1rem;
        }

        .product-name {
            font-weight: 600;
            font-size: 1rem;
            color: var(--dark-color);
            margin-bottom: 0.25rem;
            line-height: 1.4;
        }

        .product-category {
            font-size: 0.85rem;
            color: var(--gray-color);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .product-category i {
            color: var(--primary-color);
        }

        .product-price-cell {
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
        }

        .current-price {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--primary-color);
        }

        .original-price {
            font-size: 0.9rem;
            color: var(--gray-color);
            text-decoration: line-through;
        }

        .product-discount-cell {
            text-align: center;
        }

        .discount-percent {
            display: inline-block;
            background: linear-gradient(135deg, var(--accent-color), #fbbf24);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            font-weight: 700;
            font-size: 0.9rem;
            box-shadow: var(--shadow-sm);
        }

        .product-action-cell {
            text-align: right;
        }

        .view-product-btn {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            color: white;
            padding: 0.6rem 1.2rem;
            border-radius: 8px;
            font-weight: 600;
            font-size: 0.9rem;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: var(--transition);
            text-decoration: none;
        }

        .view-product-btn:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
            color: white;
        }

        /* MOBILE PRODUCT VIEW - HORIZONTAL CARDS */
        .mobile-product-scroll {
            display: none;
            overflow-x: auto;
            padding: 0.5rem 0 1rem;
            -webkit-overflow-scrolling: touch;
            scrollbar-width: thin;
            scrollbar-color: var(--primary-color) transparent;
        }

        .mobile-product-scroll::-webkit-scrollbar {
            height: 6px;
        }

        .mobile-product-scroll::-webkit-scrollbar-track {
            background: transparent;
        }

        .mobile-product-scroll::-webkit-scrollbar-thumb {
            background: var(--primary-color);
            border-radius: 3px;
        }

        .mobile-product-card {
            flex: 0 0 auto;
            width: 160px;
            margin-right: 1rem;
            background: white;
            border-radius: var(--radius-sm);
            box-shadow: var(--shadow-sm);
            overflow: hidden;
            transition: var(--transition);
            border: 1px solid rgba(0,0,0,0.05);
        }

        .mobile-product-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-md);
        }

        .mobile-product-image {
            position: relative;
            height: 120px;
            overflow: hidden;
        }

        .mobile-product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .mobile-diskon-badge {
            position: absolute;
            top: 8px;
            left: 8px;
            background: linear-gradient(135deg, var(--danger-color), #f87171);
            color: white;
            padding: 0.2rem 0.5rem;
            border-radius: 4px;
            font-size: 0.7rem;
            font-weight: 700;
            z-index: 2;
        }

        .mobile-product-info {
            padding: 0.75rem;
        }

        .mobile-product-name {
            font-weight: 600;
            font-size: 0.85rem;
            color: var(--dark-color);
            margin-bottom: 0.25rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .mobile-product-category {
            font-size: 0.75rem;
            color: var(--gray-color);
            margin-bottom: 0.5rem;
        }

        .mobile-price-container {
            display: flex;
            flex-direction: column;
            gap: 0.1rem;
            margin-bottom: 0.5rem;
        }

        .mobile-current-price {
            font-size: 0.95rem;
            font-weight: 700;
            color: var(--primary-color);
        }

        .mobile-original-price {
            font-size: 0.75rem;
            color: var(--gray-color);
            text-decoration: line-through;
        }

        .mobile-view-btn {
            width: 100%;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            color: white;
            padding: 0.4rem;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.25rem;
            transition: var(--transition);
        }

        .mobile-view-btn:hover {
            opacity: 0.9;
        }

        /* NO PRODUCTS */
        .no-products {
            text-align: center;
            padding: 4rem 2rem;
            background: white;
            border-radius: var(--radius-md);
            box-shadow: var(--shadow-sm);
        }

        .no-products i {
            font-size: 4rem;
            color: var(--gray-color);
            margin-bottom: 1.5rem;
            opacity: 0.5;
        }

        .no-products h4 {
            color: var(--dark-color);
            margin-bottom: 0.5rem;
        }

        /* FOOTER */
        .footer {
            background: linear-gradient(135deg, #1f2937 0%, #111827 100%);
            color: white;
            padding: 4rem 0 2rem;
            margin-top: 4rem;
        }

        .footer h5 {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            font-size: 1.25rem;
            margin-bottom: 1.5rem;
            color: white;
        }

        .footer p {
            color: #cbd5e1;
            font-size: 0.95rem;
            line-height: 1.7;
        }

        .footer-link {
            color: #cbd5e1;
            text-decoration: none;
            transition: var(--transition);
            display: inline-block;
            margin-bottom: 0.5rem;
            font-size: 0.95rem;
        }

        .footer-link:hover {
            color: white;
            transform: translateX(5px);
        }

        .social-icons {
            display: flex;
            gap: 1rem;
        }

        .social-icons a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            color: white;
            text-decoration: none;
            transition: var(--transition);
        }

        .social-icons a:hover {
            background: var(--primary-color);
            transform: translateY(-3px);
        }

        .payment-method {
            width: 60px;
            height: 40px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 0.8rem;
        }

        .copyright {
            text-align: center;
            padding-top: 2rem;
            margin-top: 2rem;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: #94a3b8;
            font-size: 0.9rem;
        }

        /* TABLE HEADER */
        .table-header {
            display: grid;
            grid-template-columns: 120px 2fr 1fr 1fr 150px;
            gap: 1rem;
            padding: 0.75rem 1rem;
            background: var(--primary-color);
            color: white;
            border-radius: var(--radius-sm);
            margin-bottom: 0.5rem;
            font-weight: 600;
            font-size: 0.9rem;
        }

        /* RESPONSIVE */
        @media (max-width: 992px) {
            .product-row,
            .table-header {
                grid-template-columns: 100px 1.5fr 1fr 0.8fr 130px;
                gap: 0.75rem;
                padding: 0.75rem;
            }
            
            .product-image-cell {
                height: 80px;
            }
            
            .view-product-btn {
                padding: 0.5rem 1rem;
                font-size: 0.85rem;
            }
        }

        @media (max-width: 768px) {
            .section-header h2 {
                font-size: 2rem;
            }
            
            .banner-img {
                height: 250px;
            }
            
            .carousel-control-prev,
            .carousel-control-next {
                width: 40px;
                height: 40px;
                margin: 0 10px;
            }
            
            .category-buttons {
                overflow-x: auto;
                padding-bottom: 0.5rem;
                justify-content: flex-start;
                scrollbar-width: thin;
                scrollbar-color: var(--primary-color) transparent;
            }
            
            .category-buttons::-webkit-scrollbar {
                height: 4px;
            }
            
            .category-buttons::-webkit-scrollbar-track {
                background: transparent;
            }
            
            .category-buttons::-webkit-scrollbar-thumb {
                background: var(--primary-color);
                border-radius: 2px;
            }
            
            /* HIDE DESKTOP TABLE, SHOW MOBILE SCROLL */
            .product-table-container {
                display: none;
            }
            
            .mobile-product-scroll {
                display: flex;
            }
        }

        /* UTILITIES */
        .gradient-text {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .gradient-bg {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        }

        /* ANIMATIONS */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .animate-fade-in {
            animation: fadeIn 0.5s ease forwards;
        }
    </style>
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-gem"></i>Virallinstore.id
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarContent">
                <form class="d-flex mx-auto my-2 my-lg-0 w-100 max-w-500" method="GET">
                    <div class="input-group">
                        <input type="text" class="form-control nav-search" placeholder="Cari produk terbaik, kategori, atau merek..." name="search" value="<?= htmlspecialchars($keyword) ?>">
                        <button class="btn search-btn" type="submit">
                            <i class="fas fa-search me-2"></i>Cari
                        </button>
                    </div>
                </form>
                
                <div class="d-flex ms-lg-3 mt-3 mt-lg-0">
                    <a href="cart.php" class="btn cart-btn position-relative">
                        <i class="fas fa-shopping-cart"></i>
                        <span>Keranjang</span>
                        <span class="cart-count"><?= $cart_count ?></span>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- BANNER SLIDER -->
    <div class="container mt-4">
        <div id="mainBanner" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#mainBanner" data-bs-slide-to="0" class="active"></button>
                <button type="button" data-bs-target="#mainBanner" data-bs-slide-to="1"></button>
                <button type="button" data-bs-target="#mainBanner" data-bs-slide-to="2"></button>
            </div>
            
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="img/diskon.png" class="banner-img" alt="Diskon Spesial" onerror="this.src='https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80'">
                </div>
                <div class="carousel-item">
                    <img src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80" class="banner-img" alt="Sepatu Pria">
                </div>
                <div class="carousel-item">
                    <img src="https://images.unsplash.com/photo-1523381210434-271e8be1f52b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80" class="banner-img" alt="Fashion Terbaru">
                </div>
            </div>
            
            <button class="carousel-control-prev" type="button" data-bs-target="#mainBanner" data-bs-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#mainBanner" data-bs-slide="next">
                <span class="carousel-control-next-icon"></span>
            </button>
        </div>
    </div>

    <!-- CATEGORY FILTER -->
    <div class="container mt-4">
        <div class="category-filter">
            <h5 class="mb-3 gradient-text">Filter Kategori</h5>
            <div class="category-buttons">
                <a href="index.php" class="btn category-btn <?= $filterKategori === '' ? 'active' : '' ?>">
                    <i class="fas fa-th-large me-2"></i>Semua
                </a>
                <?php foreach ($kategori_unik as $kategori): ?>
                    <a href="?kategori=<?= urlencode($kategori) ?>" class="btn category-btn <?= strtolower($filterKategori) === strtolower($kategori) ? 'active' : '' ?>">
                        <?= htmlspecialchars($kategori) ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- PRODUCTS SECTION -->
    <div class="container py-4">
        <!-- HEADER -->
        <div class="section-header">
            <h2>Produk Terbaru</h2>
            <p class="text-muted mt-2">Temukan produk fashion terbaik dengan harga spesial hanya untuk Anda</p>
        </div>

        <!-- DESKTOP TABLE VIEW -->
        <div class="product-table-container">
            <?php if (empty($produk)): ?>
                <div class="no-products">
                    <i class="fas fa-search fa-3x mb-3"></i>
                    <h4>Produk tidak ditemukan</h4>
                    <p class="text-muted">Coba gunakan kata kunci lain atau lihat kategori produk lainnya</p>
                    <a href="index.php" class="btn gradient-bg text-white mt-3 px-4 py-2">
                        Lihat Semua Produk
                    </a>
                </div>
            <?php else: ?>
                <!-- Table Header -->
                <div class="table-header">
                    <div>Gambar</div>
                    <div>Nama Produk</div>
                    <div>Harga</div>
                    <div>Diskon</div>
                    <div>Aksi</div>
                </div>
                
                <!-- Table Body -->
                <div class="product-table">
                    <?php foreach ($produk as $index => $p): 
                        // Hitung persentase diskon
                        $diskon_persen = 0;
                        if ($p['harga_asli'] > 0 && $p['harga_diskon'] < $p['harga_asli']) {
                            $diskon_persen = round((($p['harga_asli'] - $p['harga_diskon']) / $p['harga_asli']) * 100);
                        }
                    ?>
                        <div class="product-row animate-fade-in" style="animation-delay: <?= $index * 0.05 ?>s">
                            <!-- Gambar Produk -->
                            <div class="product-image-cell">
                                <?php if($diskon_persen > 0): ?>
                                    <div class="product-diskon-badge">
                                        <i class="fas fa-tag me-1"></i><?= $diskon_persen ?>%
                                    </div>
                                <?php endif; ?>
                                <img src="<?= htmlspecialchars($p['gambar']) ?>" 
                                     alt="<?= htmlspecialchars($p['nama']) ?>"
                                     onerror="this.src='https://images.unsplash.com/photo-1559056199-641a0ac8b55e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80'">
                            </div>
                            
                            <!-- Informasi Produk -->
                            <div class="product-info-cell">
                                <h6 class="product-name"><?= htmlspecialchars($p['nama']) ?></h6>
                                <div class="product-category">
                                    <i class="fas fa-tag"></i>
                                    <span><?= htmlspecialchars($p['kategori']) ?></span>
                                </div>
                            </div>
                            
                            <!-- Harga -->
                            <div class="product-price-cell">
                                <span class="current-price">Rp <?= number_format($p['harga_diskon'], 0, ',', '.') ?></span>
                                <?php if($p['harga_diskon'] < $p['harga_asli']): ?>
                                    <span class="original-price">Rp <?= number_format($p['harga_asli'], 0, ',', '.') ?></span>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Diskon -->
                            <div class="product-discount-cell">
                                <?php if($diskon_persen > 0): ?>
                                    <span class="discount-percent">
                                        <i class="fas fa-fire me-1"></i><?= $diskon_persen ?>% OFF
                                    </span>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Tombol Aksi -->
                            <div class="product-action-cell">
                                <a href="product.php?id=<?= $p['id'] ?>" class="view-product-btn">
                                    <i class="fas fa-eye"></i>
                                    Detail
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- MOBILE HORIZONTAL SCROLL VIEW -->
        <div class="mobile-product-scroll">
            <?php if (empty($produk)): ?>
                <div class="col-12 text-center py-5">
                    <i class="fas fa-search fa-3x mb-3 text-muted"></i>
                    <h5>Produk tidak ditemukan</h5>
                    <a href="index.php" class="btn gradient-bg text-white mt-3">
                        Lihat Semua Produk
                    </a>
                </div>
            <?php else: ?>
                <?php foreach ($produk as $index => $p): 
                    // Hitung persentase diskon untuk mobile
                    $diskon_persen_mobile = 0;
                    if ($p['harga_asli'] > 0 && $p['harga_diskon'] < $p['harga_asli']) {
                        $diskon_persen_mobile = round((($p['harga_asli'] - $p['harga_diskon']) / $p['harga_asli']) * 100);
                    }
                ?>
                    <div class="mobile-product-card animate-fade-in">
                        <div class="mobile-product-image">
                            <?php if($diskon_persen_mobile > 0): ?>
                                <div class="mobile-diskon-badge">
                                    <?= $diskon_persen_mobile ?>%
                                </div>
                            <?php endif; ?>
                            <img src="<?= htmlspecialchars($p['gambar']) ?>" 
                                 alt="<?= htmlspecialchars($p['nama']) ?>"
                                 onerror="this.src='https://images.unsplash.com/photo-1559056199-641a0ac8b55e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80'">
                        </div>
                        
                        <div class="mobile-product-info">
                            <h6 class="mobile-product-name"><?= htmlspecialchars($p['nama']) ?></h6>
                            <div class="mobile-product-category">
                                <?= htmlspecialchars($p['kategori']) ?>
                            </div>
                            
                            <div class="mobile-price-container">
                                <span class="mobile-current-price">Rp <?= number_format($p['harga_diskon'], 0, ',', '.') ?></span>
                                <?php if($p['harga_diskon'] < $p['harga_asli']): ?>
                                    <span class="mobile-original-price">Rp <?= number_format($p['harga_asli'], 0, ',', '.') ?></span>
                                <?php endif; ?>
                            </div>
                            
                            <?php if($diskon_persen_mobile > 0): ?>
                                <div class="text-center mb-2">
                                    <small class="badge bg-danger">
                                        <i class="fas fa-fire me-1"></i><?= $diskon_persen_mobile ?>% OFF
                                    </small>
                                </div>
                            <?php endif; ?>
                            
                            <a href="product.php?id=<?= $p['id'] ?>" class="mobile-view-btn">
                                <i class="fas fa-eye"></i>
                                Lihat
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <?php if (!empty($produk) && count($produk) >= 8): ?>
            <div class="text-center mt-5">
                <a href="#" class="btn btn-outline-primary px-5 py-2 rounded-pill">
                    <i class="fas fa-arrow-down me-2"></i>Lihat Lebih Banyak
                </a>
            </div>
        <?php endif; ?>
    </div>

    <!-- FOOTER -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 mb-4">
                    <h5><i class="fas fa-gem me-2"></i>VirallinStore.id</h5>
                    <p>E-commerce terpercaya dengan produk fashion berkualitas tinggi dan harga terbaik untuk gaya hidup Anda.</p>
                    <div class="social-icons mt-4">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-tiktok"></i></a>
                        <a href="#"><i class="fab fa-whatsapp"></i></a>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-6 mb-4">
                    <h5>Menu</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.php" class="footer-link"><i class="fas fa-home me-2"></i>Home</a></li>
                        <li><a href="#" class="footer-link"><i class="fas fa-box me-2"></i>Produk</a></li>
                        <li><a href="#" class="footer-link"><i class="fas fa-tags me-2"></i>Kategori</a></li>
                        <li><a href="#" class="footer-link"><i class="fas fa-percentage me-2"></i>Promo</a></li>
                        <li><a href="#" class="footer-link"><i class="fas fa-info-circle me-2"></i>Tentang Kami</a></li>
                    </ul>
                </div>
                
                <div class="col-lg-3 col-md-6 mb-4">
                    <h5>Kategori Populer</h5>
                    <ul class="list-unstyled">
                        <?php foreach (array_slice($kategori_unik, 0, 5) as $kategori): ?>
                            <li><a href="?kategori=<?= urlencode($kategori) ?>" class="footer-link">
                                <i class="fas fa-arrow-right me-2"></i><?= htmlspecialchars($kategori) ?>
                            </a></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                
                <div class="col-lg-3 col-md-6 mb-4">
                    <h5>Kontak Kami</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2">
                            <i class="fas fa-phone me-2"></i>
                            <a href="tel:08113317077" class="footer-link">0811-3317-077</a>
                        </li>
                        <li class="mb-2">
                            <i class="fas fa-envelope me-2"></i>
                            <a href="mailto:catatannewbie@gmail.com" class="footer-link">catatannewbie@gmail.com</a>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-map-marker-alt me-2"></i>Surabaya, Jawa Timur
                        </li>
                    </ul>
                    <div class="mt-4">
                        <h6>Metode Pembayaran</h6>
                        <div class="d-flex flex-wrap gap-2 mt-2">
                            <div class="payment-method">BCA</div>
                            <div class="payment-method">Mandiri</div>
                            <div class="payment-method">QRIS</div>
                            <div class="payment-method">COD</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="copyright">
                <p>&copy; <?= date("Y") ?> VirallinStore.id. All rights reserved. | Designed with <i class="fas fa-heart text-danger"></i></p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Auto slide banner
            const carousel = new bootstrap.Carousel('#mainBanner', {
                interval: 4000,
                wrap: true
            });
            
            // Cart count animation
            const cartCount = document.querySelector('.cart-count');
            if (cartCount) {
                cartCount.addEventListener('click', function() {
                    this.style.transform = 'scale(1.3) rotate(10deg)';
                    setTimeout(() => {
                        this.style.transform = 'scale(1) rotate(0deg)';
                    }, 300);
                });
            }
            
            // Smooth scroll for product rows
            const productRows = document.querySelectorAll('.product-row');
            productRows.forEach(row => {
                row.addEventListener('click', function(e) {
                    if (!e.target.closest('.view-product-btn')) {
                        const link = this.querySelector('.view-product-btn');
                        if (link) {
                            link.click();
                        }
                    }
                });
                
                // Hover effect
                row.addEventListener('mouseenter', function() {
                    this.style.cursor = 'pointer';
                });
            });
            
            // Mobile card hover effect
            const mobileCards = document.querySelectorAll('.mobile-product-card');
            mobileCards.forEach(card => {
                card.addEventListener('touchstart', function() {
                    this.style.transform = 'translateY(-4px) scale(1.02)';
                });
                
                card.addEventListener('touchend', function() {
                    this.style.transform = 'translateY(-4px)';
                });
            });
            
            // Smooth scroll to top button
            const scrollToTop = document.createElement('button');
            scrollToTop.innerHTML = '<i class="fas fa-arrow-up"></i>';
            scrollToTop.className = 'btn gradient-bg text-white rounded-circle shadow';
            scrollToTop.style.cssText = `
                position: fixed;
                bottom: 20px;
                right: 20px;
                width: 50px;
                height: 50px;
                display: none;
                z-index: 100;
                border: none;
                font-size: 1.2rem;
            `;
            document.body.appendChild(scrollToTop);
            
            window.addEventListener('scroll', function() {
                if (window.pageYOffset > 300) {
                    scrollToTop.style.display = 'flex';
                    scrollToTop.style.alignItems = 'center';
                    scrollToTop.style.justifyContent = 'center';
                } else {
                    scrollToTop.style.display = 'none';
                }
            });
            
            scrollToTop.addEventListener('click', function() {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            });
            
            // Add click animation to all buttons
            const buttons = document.querySelectorAll('button, .btn, .view-product-btn, .mobile-view-btn');
            buttons.forEach(btn => {
                btn.addEventListener('click', function(e) {
                    this.style.transform = 'scale(0.95)';
                    setTimeout(() => {
                        this.style.transform = '';
                    }, 200);
                });
            });
            
            // Prevent form submission if search is empty
            const searchForm = document.querySelector('form');
            if (searchForm) {
                searchForm.addEventListener('submit', function(e) {
                    const searchInput = this.querySelector('input[name="search"]');
                    if (searchInput.value.trim() === '') {
                        e.preventDefault();
                        searchInput.focus();
                        searchInput.style.borderColor = 'var(--danger-color)';
                        searchInput.style.boxShadow = '0 0 0 3px rgba(239, 68, 68, 0.1)';
                        setTimeout(() => {
                            searchInput.style.borderColor = '';
                            searchInput.style.boxShadow = '';
                        }, 1000);
                    }
                });
            }
            
            // Add loading animation to images
            const images = document.querySelectorAll('img');
            images.forEach(img => {
                img.addEventListener('load', function() {
                    this.style.opacity = '1';
                });
                img.style.opacity = '0';
                img.style.transition = 'opacity 0.3s ease';
            });
            
            // Mobile horizontal scroll auto-centering
            const mobileScroll = document.querySelector('.mobile-product-scroll');
            if (mobileScroll) {
                let isScrolling;
                mobileScroll.addEventListener('scroll', function() {
                    window.clearTimeout(isScrolling);
                    isScrolling = setTimeout(() => {
                        // Find the card closest to center and add active class
                        const cards = this.querySelectorAll('.mobile-product-card');
                        const containerCenter = this.scrollLeft + (this.clientWidth / 2);
                        
                        let closestCard = null;
                        let closestDistance = Infinity;
                        
                        cards.forEach(card => {
                            const cardCenter = card.offsetLeft + (card.offsetWidth / 2);
                            const distance = Math.abs(containerCenter - cardCenter);
                            
                            if (distance < closestDistance) {
                                closestDistance = distance;
                                closestCard = card;
                            }
                        });
                        
                        // Remove active class from all cards
                        cards.forEach(card => {
                            card.classList.remove('active');
                        });
                        
                        // Add active class to closest card
                        if (closestCard) {
                            closestCard.classList.add('active');
                        }
                    }, 150);
                });
            }
            
            // Initialize animations
            const animatedElements = document.querySelectorAll('.animate-fade-in');
            animatedElements.forEach((el, index) => {
                el.style.animationDelay = `${index * 0.05}s`;
            });
        });
    </script>
</body>
</html>