<?php
session_start();

// Fungsi untuk mengirim notifikasi ke Telegram
function sendTelegramNotification($message, $photo_path = null) {
    $botToken = '8547597830:AAH4JVmHQ5RQXxU4IgYOiZ34qWtIHHbYB_c'; // Ganti dengan token bot Telegram Anda
    $chatId = '1918776376'; // Ganti dengan chat ID Anda
    
    // Jika ada foto, kirim foto dengan caption
    if ($photo_path && file_exists($photo_path)) {
        $url = "https://api.telegram.org/bot{$botToken}/sendPhoto";
        
        $post_data = [
            'chat_id' => $chatId,
            'caption' => $message,
            'parse_mode' => 'HTML'
        ];
        
        // CURL untuk upload file
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        
        // Siapkan file untuk upload
        $post_data['photo'] = new CURLFile(realpath($photo_path));
        
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        $result = curl_exec($ch);
        curl_close($ch);
        
        return $result;
    } else {
        // Kirim pesan text saja
        $url = "https://api.telegram.org/bot{$botToken}/sendMessage";
        
        $data = [
            'chat_id' => $chatId,
            'text' => $message,
            'parse_mode' => 'HTML'
        ];
        
        $options = [
            'http' => [
                'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                'method' => 'POST',
                'content' => http_build_query($data),
            ],
        ];
        
        $context = stream_context_create($options);
        @file_get_contents($url, false, $context);
        
        return true;
    }
}

// Fungsi untuk upload file
function uploadPaymentProof($file, $order_id, $payment_method) {
    $upload_dir = 'payment_proofs/';
    
    // Buat folder jika belum ada
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    // Validasi file
    $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp', 'application/pdf'];
    $max_size = 5 * 1024 * 1024; // 5MB
    
    if (!in_array($file['type'], $allowed_types)) {
        return ['error' => 'Format file tidak didukung. Gunakan JPG, PNG, GIF, WEBP, atau PDF.'];
    }
    
    if ($file['size'] > $max_size) {
        return ['error' => 'File terlalu besar. Maksimal 5MB.'];
    }
    
    // Generate nama file unik
    $file_extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $file_name = $payment_method . '_' . $order_id . '_' . time() . '.' . $file_extension;
    $file_path = $upload_dir . $file_name;
    
    // Pindahkan file ke folder upload
    if (move_uploaded_file($file['tmp_name'], $file_path)) {
        return [
            'success' => true,
            'file_path' => $file_path,
            'file_name' => $file_name
        ];
    } else {
        return ['error' => 'Gagal mengupload file.'];
    }
}

// Proses form pembayaran
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form
    $payment_method = $_POST['payment_method'] ?? '';
    $product_id = $_POST['product_id'] ?? '';
    $product_name = $_POST['product_name'] ?? '';
    $product_price = $_POST['product_price'] ?? 0;
    $quantity = $_POST['quantity'] ?? 1;
    $selected_size = $_POST['selected_size'] ?? '';
    $selected_color = $_POST['selected_color'] ?? '';
    $selected_other = $_POST['selected_other'] ?? '';
    
    // Data pelanggan
    $full_name = $_POST['full_name'] ?? '';
    $phone_number = $_POST['phone_number'] ?? '';
    $email = $_POST['email'] ?? '';
    $address = $_POST['address'] ?? '';
    $province = $_POST['province'] ?? '';
    $city = $_POST['city'] ?? '';
    $postal_code = $_POST['postal_code'] ?? '';
    
    // Data pembayaran spesifik
    $payment_details = [];
    if ($payment_method === 'crypto') {
        $payment_details = [
            'wallet_type' => $_POST['crypto_wallet'] ?? '',
            'amount' => $_POST['crypto_amount'] ?? '',
            'sender_address' => $_POST['crypto_address'] ?? ''
        ];
    } elseif ($payment_method === 'bank_transfer') {
        $payment_details = [
            'bank_name' => $_POST['bank_name'] ?? ''
        ];
    }
    
    // Generate order ID
    $order_id = 'ORD-' . date('Ymd') . '-' . strtoupper(substr(md5(uniqid()), 0, 6));
    
    // Hitung total
    $shipping_cost = 15000;
    $total_price = ($product_price * $quantity) + $shipping_cost;
    
    // Proses upload bukti pembayaran
    $proof_info = null;
    $proof_file_path = null;
    
    if (isset($_FILES['payment_proof']) && $_FILES['payment_proof']['error'] === UPLOAD_ERR_OK) {
        $upload_result = uploadPaymentProof($_FILES['payment_proof'], $order_id, $payment_method);
        
        if (isset($upload_result['error'])) {
            // Tampilkan error dan redirect back
            $_SESSION['payment_error'] = $upload_result['error'];
            header("Location: " . $_SERVER['HTTP_REFERER']);
            exit();
        }
        
        if (isset($upload_result['success'])) {
            $proof_info = $upload_result;
            $proof_file_path = $upload_result['file_path'];
        }
    }
    
    // Simpan data order ke file JSON
    $backup_file = 'orders_backup.json';
    $backup_data = [];
    
    if (file_exists($backup_file)) {
        $existing_data = file_get_contents($backup_file);
        $backup_data = json_decode($existing_data, true) ?? [];
    }
    
    // Buat data order
    $order_data = [
        'order_id' => $order_id,
        'product_id' => $product_id,
        'product_name' => $product_name,
        'product_price' => (float)$product_price,
        'quantity' => (int)$quantity,
        'selected_size' => $selected_size,
        'selected_color' => $selected_color,
        'selected_other' => $selected_other,
        'total_price' => (float)$total_price,
        'payment_method' => $payment_method,
        'payment_details' => $payment_details,
        'customer_name' => $full_name,
        'customer_phone' => $phone_number,
        'customer_email' => $email,
        'customer_address' => $address,
        'province' => $province,
        'city' => $city,
        'postal_code' => $postal_code,
        'payment_proof' => $proof_info ? $proof_info['file_name'] : null,
        'status' => 'pending',
        'created_at' => date('Y-m-d H:i:s')
    ];
    
    // Tambahkan ke array backup
    $backup_data[] = $order_data;
    
    // Simpan ke file JSON
    file_put_contents($backup_file, json_encode($backup_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    
    // Kirim notifikasi ke Telegram
    $telegram_message = "🚀 *ORDER BARU DITERIMA!*\n\n";
    $telegram_message .= "📦 *Detail Order:*\n";
    $telegram_message .= "🆔 Order ID: `$order_id`\n";
    $telegram_message .= "📋 Produk: $product_name\n";
    $telegram_message .= "💰 Harga Satuan: Rp " . number_format($product_price, 0, ',', '.') . "\n";
    $telegram_message .= "🔢 Jumlah: $quantity\n";
    
    if ($selected_size) {
        $telegram_message .= "📏 Ukuran: $selected_size\n";
    }
    if ($selected_color) {
        $telegram_message .= "🎨 Warna: $selected_color\n";
    }
    if ($selected_other) {
        $telegram_message .= "✨ Pilihan: $selected_other\n";
    }
    
    $telegram_message .= "🚚 Ongkir: Rp " . number_format($shipping_cost, 0, ',', '.') . "\n";
    $telegram_message .= "💰 *Total: Rp " . number_format($total_price, 0, ',', '.') . "*\n\n";
    
    $telegram_message .= "💳 *Metode Pembayaran:* " . strtoupper($payment_method) . "\n";
    
    if ($payment_method === 'crypto') {
        $telegram_message .= "💰 Wallet: " . strtoupper($payment_details['wallet_type']) . "\n";
        $telegram_message .= "📊 Amount: " . $payment_details['amount'] . "\n";
        if (!empty($payment_details['sender_address'])) {
            $telegram_message .= "📍 Sender: " . substr($payment_details['sender_address'], 0, 20) . "...\n";
        }
    } elseif ($payment_method === 'bank_transfer') {
        $telegram_message .= "🏦 Bank: " . strtoupper($payment_details['bank_name']) . "\n";
    }
    
    $telegram_message .= "\n👤 *Data Pelanggan:*\n";
    $telegram_message .= "👨‍💼 Nama: $full_name\n";
    $telegram_message .= "📱 Telepon: $phone_number\n";
    $telegram_message .= "📧 Email: $email\n";
    $telegram_message .= "📍 Alamat: $address\n";
    $telegram_message .= "🏙️ Kota: $city, $province\n";
    $telegram_message .= "📮 Kode Pos: $postal_code\n\n";
    $telegram_message .= "⏰ Waktu Order: " . date('d-m-Y H:i:s') . "\n";
    
    if ($proof_info) {
        $telegram_message .= "✅ *Bukti pembayaran terlampir*";
    } else {
        $telegram_message .= "⚠️ *Tidak ada bukti pembayaran yang diupload*";
    }
    
    // Kirim notifikasi ke Telegram
    if ($proof_file_path) {
        // Kirim dengan foto
        sendTelegramNotification($telegram_message, $proof_file_path);
    } else {
        // Kirim hanya pesan
        sendTelegramNotification($telegram_message);
    }
    
    // Simpan ke session untuk halaman success
    $_SESSION['last_order'] = $order_data;
    
    // Redirect ke halaman success
    header("Location: payment_success.php?order_id=" . $order_id);
    exit();
    
} else {
    header("Location: index.php");
    exit();
}