<?php
session_start();

// Ambil data order dari session
$order_id = $_GET['order_id'] ?? '';
$last_order = $_SESSION['last_order'] ?? null;

// Jika tidak ada di session, cari di backup file
if (!$last_order && $order_id) {
    $backup_file = 'orders_backup.json';
    if (file_exists($backup_file)) {
        $orders = json_decode(file_get_contents($backup_file), true) ?? [];
        foreach ($orders as $order) {
            if ($order['order_id'] === $order_id) {
                $last_order = $order;
                break;
            }
        }
    }
}

// Jika masih tidak ditemukan, redirect ke home
if (!$last_order) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembayaran Berhasil - Security77 Store</title>
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .success-card {
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 700px;
            width: 100%;
            text-align: center;
        }
        
        .success-icon {
            font-size: 80px;
            color: #28a745;
            margin-bottom: 20px;
        }
        
        .order-details {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
            text-align: left;
        }
        
        .detail-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            padding-bottom: 10px;
            border-bottom: 1px solid #e9ecef;
        }
        
        .detail-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }
        
        .btn-whatsapp {
            background: #25D366;
            color: white;
            padding: 12px 30px;
            font-weight: 600;
            border-radius: 8px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: all 0.3s;
        }
        
        .btn-whatsapp:hover {
            background: #128C7E;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(37, 211, 102, 0.4);
        }
        
        .btn-home {
            background: #6c757d;
            color: white;
            padding: 12px 30px;
            font-weight: 600;
            border-radius: 8px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: all 0.3s;
        }
        
        .btn-home:hover {
            background: #545b62;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(108, 117, 125, 0.4);
        }
        
        .order-id {
            font-family: monospace;
            background: #e9ecef;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 1.1em;
        }
        
        .payment-method-badge {
            background: #6f42c1;
            color: white;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.9em;
            font-weight: 500;
        }
        
        .customer-info {
            background: #e9ecef;
            border-radius: 10px;
            padding: 15px;
            margin: 15px 0;
        }
        
        .proof-uploaded {
            background: #d1ecf1;
            border: 2px solid #bee5eb;
            border-radius: 10px;
            padding: 15px;
            margin: 15px 0;
        }
        
        .proof-icon {
            font-size: 40px;
            color: #0c5460;
            margin-bottom: 10px;
        }
        
        .proof-status {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            background: #0c5460;
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9em;
        }
        
        .telegram-info {
            background: #0088cc;
            color: white;
            border-radius: 10px;
            padding: 15px;
            margin: 15px 0;
        }
        
        .telegram-icon {
            font-size: 24px;
        }
    </style>
</head>
<body>
    <div class="success-card">
        <div class="success-icon">
            <i class="fas fa-check-circle"></i>
        </div>
        
        <h1 class="mb-3">Pembayaran Berhasil!</h1>
        <p class="text-muted mb-4">Terima kasih telah berbelanja di Security77 Store. Order Anda telah berhasil diproses.</p>
        
        <!-- Info Telegram -->
        <div class="telegram-info">
            <div class="d-flex align-items-center justify-content-center gap-3 mb-2">
                <i class="fab fa-telegram telegram-icon"></i>
                <h5 class="mb-0">Notifikasi Terkirim ke Telegram</h5>
            </div>
            <p class="mb-0 small">Bukti pembayaran dan detail order telah dikirim ke admin untuk verifikasi.</p>
        </div>
        
        <!-- Order Details -->
        <div class="order-details">
            <div class="detail-item">
                <span>Order ID:</span>
                <strong class="order-id"><?= htmlspecialchars($last_order['order_id']) ?></strong>
            </div>
            
            <div class="detail-item">
                <span>Produk:</span>
                <strong><?= htmlspecialchars($last_order['product_name']) ?></strong>
            </div>
            
            <div class="detail-item">
                <span>Harga Satuan:</span>
                <span>Rp <?= number_format($last_order['product_price'], 0, ',', '.') ?></span>
            </div>
            
            <div class="detail-item">
                <span>Jumlah:</span>
                <span><?= $last_order['quantity'] ?> unit</span>
            </div>
            
            <?php if (!empty($last_order['selected_size'])): ?>
            <div class="detail-item">
                <span>Ukuran:</span>
                <strong><?= htmlspecialchars($last_order['selected_size']) ?></strong>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($last_order['selected_color'])): ?>
            <div class="detail-item">
                <span>Warna:</span>
                <strong><?= htmlspecialchars($last_order['selected_color']) ?></strong>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($last_order['selected_other'])): ?>
            <div class="detail-item">
                <span>Pilihan:</span>
                <strong><?= htmlspecialchars($last_order['selected_other']) ?></strong>
            </div>
            <?php endif; ?>
            
            <div class="detail-item">
                <span>Metode Pembayaran:</span>
                <span class="payment-method-badge">
                    <?= strtoupper($last_order['payment_method']) ?>
                    <?php if ($last_order['payment_method'] === 'crypto' && isset($last_order['payment_details']['wallet_type'])): ?>
                        (<?= strtoupper($last_order['payment_details']['wallet_type']) ?>)
                    <?php elseif ($last_order['payment_method'] === 'bank_transfer' && isset($last_order['payment_details']['bank_name'])): ?>
                        (<?= strtoupper($last_order['payment_details']['bank_name']) ?>)
                    <?php endif; ?>
                </span>
            </div>
            
            <div class="detail-item">
                <span>Ongkir:</span>
                <span>Rp 15.000</span>
            </div>
            
            <div class="detail-item total-item">
                <span><strong>Total Pembayaran:</strong></span>
                <strong class="text-primary">Rp <?= number_format($last_order['total_price'], 0, ',', '.') ?></strong>
            </div>
        </div>
        
        <!-- Bukti Pembayaran -->
        <?php if (!empty($last_order['proof_filename'])): ?>
        <div class="proof-uploaded">
            <div class="proof-icon">
                <i class="fas fa-file-upload"></i>
            </div>
            <h6>Bukti Pembayaran Terupload</h6>
            <p class="mb-2">
                <i class="fas fa-paperclip me-2"></i>
                <strong><?= htmlspecialchars($last_order['proof_filename']) ?></strong>
            </p>
            <div class="proof-status">
                <i class="fas fa-paper-plane"></i>
                <span>Terkirim ke Telegram</span>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Customer Info -->
        <div class="customer-info">
            <h6 class="mb-3"><i class="fas fa-user me-2"></i>Data Pelanggan</h6>
            <div class="row">
                <div class="col-md-6">
                    <p class="mb-1"><small><strong>Nama:</strong> <?= htmlspecialchars($last_order['customer_name']) ?></small></p>
                    <p class="mb-1"><small><strong>Telepon:</strong> <?= htmlspecialchars($last_order['customer_phone']) ?></small></p>
                    <p class="mb-1"><small><strong>Email:</strong> <?= htmlspecialchars($last_order['customer_email']) ?></small></p>
                </div>
                <div class="col-md-6">
                    <p class="mb-1"><small><strong>Alamat:</strong> <?= htmlspecialchars($last_order['customer_address']) ?></small></p>
                    <p class="mb-1"><small><strong>Kota:</strong> <?= htmlspecialchars($last_order['city']) ?>, <?= htmlspecialchars($last_order['province']) ?></small></p>
                    <p class="mb-0"><small><strong>Kode Pos:</strong> <?= htmlspecialchars($last_order['postal_code']) ?></small></p>
                </div>
            </div>
        </div>
        
        <!-- Status & Info -->
        <div class="alert alert-info mb-4">
            <i class="fas fa-info-circle me-2"></i>
            <div>
                <strong>Status Order:</strong> 
                <span class="badge bg-warning">MENUNGGU VERIFIKASI</span><br>
                <small class="mt-1 d-block">Order Anda sedang diverifikasi. Admin akan memeriksa bukti pembayaran yang telah dikirim ke Telegram.</small>
            </div>
        </div>
        
        <!-- Action Buttons -->
        <div class="d-flex flex-column flex-md-row gap-3 justify-content-center mb-4">
            <?php
            $wa_nomor = "628113317077";
            $order_details = "";
            
            // Buat detail order untuk WhatsApp
            $order_details .= "Order ID: " . $last_order['order_id'] . "\n";
            $order_details .= "Produk: " . $last_order['product_name'] . "\n";
            $order_details .= "Harga: Rp " . number_format($last_order['product_price'], 0, ',', '.') . "\n";
            $order_details .= "Jumlah: " . $last_order['quantity'] . "\n";
            
            if (!empty($last_order['selected_size'])) {
                $order_details .= "Ukuran: " . $last_order['selected_size'] . "\n";
            }
            if (!empty($last_order['selected_color'])) {
                $order_details .= "Warna: " . $last_order['selected_color'] . "\n";
            }
            if (!empty($last_order['selected_other'])) {
                $order_details .= "Pilihan: " . $last_order['selected_other'] . "\n";
            }
            
            $order_details .= "Total: Rp " . number_format($last_order['total_price'], 0, ',', '.') . "\n";
            $order_details .= "Metode: " . strtoupper($last_order['payment_method']);
            
            if ($last_order['payment_method'] === 'crypto' && isset($last_order['payment_details']['wallet_type'])) {
                $order_details .= " (" . strtoupper($last_order['payment_details']['wallet_type']) . ")";
            } elseif ($last_order['payment_method'] === 'bank_transfer' && isset($last_order['payment_details']['bank_name'])) {
                $order_details .= " (" . strtoupper($last_order['payment_details']['bank_name']) . ")";
            }
            
            $order_details .= "\n\nBukti pembayaran sudah diupload dan dikirim ke Telegram.";
            
            $wa_text = urlencode("Halo, saya sudah melakukan pembayaran untuk order:\n\n" . $order_details . "\n\nNama: " . $last_order['customer_name'] . "\nTelepon: " . $last_order['customer_phone'] . "\n\nMohon konfirmasi pembayaran saya.");
            $wa_link = "https://wa.me/$wa_nomor?text=$wa_text";
            ?>
            
            <a href="<?= $wa_link ?>" target="_blank" class="btn-whatsapp">
                <i class="fab fa-whatsapp"></i> Konfirmasi via WhatsApp
            </a>
            
            <a href="index.php" class="btn-home">
                <i class="fas fa-home"></i> Kembali ke Beranda
            </a>
        </div>
        
        <!-- Save Order Info -->
        <div class="text-center">
            <button onclick="printOrder()" class="btn btn-outline-primary btn-sm me-2">
                <i class="fas fa-print"></i> Cetak Order
            </button>
            <button onclick="copyOrderID()" class="btn btn-outline-secondary btn-sm">
                <i class="fas fa-copy"></i> Salin Order ID
            </button>
            <?php if (!empty($last_order['proof_filename'])): ?>
            <button onclick="viewProof()" class="btn btn-outline-success btn-sm">
                <i class="fas fa-eye"></i> Lihat Bukti
            </button>
            <?php endif; ?>
        </div>
        
        <!-- Important Notes -->
        <div class="mt-4 text-muted small">
            <p><strong>Proses Verifikasi:</strong></p>
            <ol class="text-start">
                <li>Admin menerima notifikasi di Telegram (pesan + foto bukti)</li>
                <li>Admin memverifikasi bukti pembayaran</li>
                <li>Status order akan diupdate menjadi "Diproses"</li>
                <li>Anda akan mendapat notifikasi via WhatsApp</li>
                <li>Produk akan dikirim dalam 1-2 hari kerja setelah verifikasi</li>
            </ol>
            <p class="mt-2"><strong>Butuh bantuan?</strong> Hubungi kami di 0811-3317-077</p>
        </div>
    </div>
    
    <!-- JavaScript -->
    <script>
        // Fungsi untuk mencetak order
        function printOrder() {
            window.print();
        }
        
        // Fungsi untuk menyalin Order ID
        function copyOrderID() {
            const orderId = "<?= $last_order['order_id'] ?>";
            navigator.clipboard.writeText(orderId).then(() => {
                alert('Order ID berhasil disalin: ' + orderId);
            });
        }
        
        // Fungsi untuk melihat bukti pembayaran
        function viewProof() {
            const proofPath = "<?= !empty($last_order['proof_filename']) ? 'uploads/payment_proofs/' . $last_order['proof_filename'] : '' ?>";
            if (proofPath) {
                window.open(proofPath, '_blank');
            }
        }
        
        // Cegah pengiriman form ulang saat refresh
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
    
    <!-- Print Style -->
    <style media="print">
        @media print {
            body {
                background: white !important;
            }
            .success-card {
                box-shadow: none !important;
                padding: 20px !important;
            }
            .btn-whatsapp, .btn-home, .btn-outline-primary, .btn-outline-secondary, .btn-outline-success {
                display: none !important;
            }
            .telegram-info, .proof-uploaded {
                background: white !important;
                border: 1px solid #ddd !important;
                color: black !important;
            }
        }
    </style>
</body>
</html>